// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'dart:convert';
//
// class EditProfile extends StatefulWidget {
//   const EditProfile({Key? key}) : super(key: key);
//
//   @override
//   State<EditProfile> createState() => _EditProfileState();
// }
//
// class _EditProfileState extends State<EditProfile> {
//   final _formKey = GlobalKey<FormState>();
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController genderController = TextEditingController();
//   final TextEditingController placeController = TextEditingController();
//   final TextEditingController pinController = TextEditingController();
//   final TextEditingController postController = TextEditingController();
//   final TextEditingController phoneController = TextEditingController();
//   final TextEditingController emailController = TextEditingController();
//   String? _oldImageUrl;
//   File? _selectedImage;
//
//   _EditProfileState() {
//     _getData();
//   }
//
//   void _getData() async {
//     SharedPreferences sh = await SharedPreferences.getInstance();
//     String url = sh.getString('url') ?? '';
//     String lid = sh.getString('lid') ?? '';
//
//     final Uri apiUrl = Uri.parse(url+'and_view_profile1');
//     try {
//       final response = await http.post(apiUrl, body: {'lid': lid});
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         if (data['status'] == 'ok') {
//           setState(() {
//             nameController.text = data['name'];
//             genderController.text = data['gender'];
//             placeController.text = data['place'];
//             postController.text = data['post'];
//             pinController.text = data['pin'];
//             phoneController.text = data['phone'];
//             emailController.text = data['email'];
//             _oldImageUrl = data['image'];
//           });
//         } else {
//           Fluttertoast.showToast(msg: 'Data Not Found');
//         }
//       } else {
//         Fluttertoast.showToast(msg: 'Network Error');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: e.toString());
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Edit Profile'),
//         backgroundColor: Colors.teal,
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               _buildTextField("Name", nameController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your name';
//                 }
//                 return null;
//               }),
//               _buildTextField("Place", placeController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your place';
//                 }
//                 return null;
//               }),
//               _buildTextField("Post", postController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your Post';
//                 }
//                 return null;
//               }),
//               _buildTextField("Pin", pinController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your pin';
//                 }
//                 return null;
//               }),
//               _buildTextField("Phone", phoneController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your phone number';
//                 }
//                 if (!RegExp(r'^[6789]\d{9}$').hasMatch(value)) {
//                   return 'Please enter a valid phone number';
//                 }
//                 return null;
//               }),
//               _buildTextField("Email", emailController, (value) {
//                 if (value == null || value.isEmpty) {
//                   return 'Please enter your email';
//                 }
//                 if (!RegExp(r'^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$').hasMatch(value)) {
//                   return 'Please enter a valid email';
//                 }
//                 return null;
//               }),
//               const SizedBox(height: 20),
//               _buildImagePicker(),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: _sendData,
//                 child: const Text("Confirm Edit"),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Padding _buildTextField(
//       String label, TextEditingController controller, String? Function(String?) validator) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 8.0),
//       child: TextFormField(
//         controller: controller,
//         decoration: InputDecoration(
//           border: const OutlineInputBorder(),
//           labelText: label,
//         ),
//         validator: validator,
//       ),
//     );
//   }
//
//   Widget _buildImagePicker() {
//     return InkWell(
//       onTap: _checkPermissionAndChooseImage,
//       child: Column(
//         children: [
//           _selectedImage != null
//               ? Image.file(_selectedImage!, height: 200, width: 200)
//               : _oldImageUrl != null && _oldImageUrl!.isNotEmpty
//
//               ? Image.network(_oldImageUrl!, height: 200, width: 200)
//               : Image.network(
//             'https://cdn.pixabay.com/photo/2017/11/10/05/24/select-2935439_1280.png',
//             height: 200,
//             width: 200,
//           ),
//           const Text('Select Image', style: TextStyle(color: Colors.cyan)),
//         ],
//       ),
//     );
//   }
//
//   Future<void> _chooseAndUploadImage() async {
//     final picker = ImagePicker();
//     final pickedImage = await picker.pickImage(source: ImageSource.gallery);
//     if (pickedImage != null) {
//       setState(() {
//         _selectedImage = File(pickedImage.path);
//       });
//     }
//   }
//
//   Future<void> _checkPermissionAndChooseImage() async {
//     final PermissionStatus status = await Permission.mediaLibrary.request();
//     if (status.isGranted) {
//       _chooseAndUploadImage();
//     } else {
//       _showPermissionDeniedDialog();
//     }
//   }
//
//   void _showPermissionDeniedDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) => AlertDialog(
//         title: const Text('Permission Denied'),
//         content: const Text(
//             'Please go to app settings and grant permission to choose an image.'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('OK'),
//           ),
//         ],
//       ),
//     );
//   }
//
//   void _sendData() async {
//     if (_formKey.currentState!.validate()) {
//       SharedPreferences sh = await SharedPreferences.getInstance();
//       String url = sh.getString('url') ?? '';
//       String lid = sh.getString('lid') ?? '';
//
//       final request = http.MultipartRequest('POST', Uri.parse(url+'edit_prf'))
//         ..fields['lid'] = lid
//         ..fields['name'] = nameController.text
//         ..fields['place'] = placeController.text
//         ..fields['post'] = postController.text
//         ..fields['pin'] = pinController.text
//         ..fields['phone'] = phoneController.text
//         ..fields['email'] = emailController.text;
//
//       if (_selectedImage != null) {
//         request.files.add(await http.MultipartFile.fromPath('image', _selectedImage!.path));
//       }
//
//       try {
//         final response = await request.send();
//         final responseData = await http.Response.fromStream(response);
//         final jsonResponse = json.decode(responseData.body);
//
//         if (jsonResponse['status'] == 'ok') {
//           Fluttertoast.showToast(msg: 'Profile updated successfully');
//           Navigator.pop(context);
//         } else {
//           Fluttertoast.showToast(msg: 'Failed to update profile');
//         }
//       } catch (e) {
//         Fluttertoast.showToast(msg: 'Error: $e');
//       }
//     }
//   }
// }




import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'dart:convert';

class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);

  @override
  State<EditProfile> createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final TextEditingController placeController = TextEditingController();
  final TextEditingController pinController = TextEditingController();
  final TextEditingController postController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  String? _oldImageUrl;
  File? _selectedImage;

  _EditProfileState() {
    _getData();
  }

  void _getData() async {
    SharedPreferences sh = await SharedPreferences.getInstance();
    String url = sh.getString('url') ?? '';
    String lid = sh.getString('lid') ?? '';

    final Uri apiUrl = Uri.parse(url+'and_view_profile1');
    try {
      final response = await http.post(apiUrl, body: {'lid': lid});
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['status'] == 'ok') {
          setState(() {
            nameController.text = data['name'];
            genderController.text = data['gender'];
            placeController.text = data['place'];
            postController.text = data['post'];
            pinController.text = data['pin'];
            phoneController.text = data['phone'];
            emailController.text = data['email'];
            _oldImageUrl = sh.getString("imgurl").toString()+data['image'] ?? "";

          });
        } else {
          Fluttertoast.showToast(msg: 'Data Not Found');
        }
      } else {
        Fluttertoast.showToast(msg: 'Network Error');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildTextField("Name", nameController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your name';
                }
                return null;
              }),
              _buildTextField("Place", placeController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your place';
                }
                return null;
              }),
              _buildTextField("Post", postController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your Post';
                }
                return null;
              }),
              _buildTextField("Pin", pinController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your pin';
                }
                return null;
              }),
              _buildTextField("Phone", phoneController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your phone number';
                }
                if (!RegExp(r'^[6789]\d{9}$').hasMatch(value)) {
                  return 'Please enter a valid phone number';
                }
                return null;
              }),
              _buildTextField("Email", emailController, (value) {
                if (value == null || value.isEmpty) {
                  return 'Please enter your email';
                }
                if (!RegExp(r'^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$').hasMatch(value)) {
                  return 'Please enter a valid email';
                }
                return null;
              }),
              const SizedBox(height: 20),
              _buildImagePicker(),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _sendData,
                child: const Text("Confirm Edit"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Padding _buildTextField(
      String label, TextEditingController controller, String? Function(String?) validator) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          labelText: label,
        ),
        validator: validator,
      ),
    );
  }

  Widget _buildImagePicker() {
    return InkWell(
      onTap: _checkPermissionAndChooseImage,
      child: Column(
        children: [
          _selectedImage != null
              ? Image.file(_selectedImage!, height: 200, width: 200)
              : _oldImageUrl != null && _oldImageUrl!.isNotEmpty
              ? Image.network(_oldImageUrl!, height: 200, width: 200)
              : Image.network(
            'https://cdn.pixabay.com/photo/2017/11/10/05/24/select-2935439_1280.png',
            height: 200,
            width: 200,
          ),
          const Text('Select Image', style: TextStyle(color: Colors.cyan)),
        ],
      ),
    );
  }

  Future<void> _chooseAndUploadImage() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _selectedImage = File(pickedImage.path);
      });
    }
  }

  Future<void> _checkPermissionAndChooseImage() async {
    final PermissionStatus status = await Permission.mediaLibrary.request();
    if (status.isGranted) {
      _chooseAndUploadImage();
    } else {
      _showPermissionDeniedDialog();
    }
  }

  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Permission Denied'),
        content: const Text(
            'Please go to app settings and grant permission to choose an image.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  void _sendData() async {
    if (_formKey.currentState!.validate()) {
      SharedPreferences sh = await SharedPreferences.getInstance();
      String url = sh.getString('url') ?? '';
      String lid = sh.getString('lid') ?? '';

      final request = http.MultipartRequest('POST', Uri.parse(url+'edit_prf'))
        ..fields['lid'] = lid
        ..fields['name'] = nameController.text
        ..fields['place'] = placeController.text
        ..fields['post'] = postController.text
        ..fields['pin'] = pinController.text
        ..fields['phone'] = phoneController.text
        ..fields['email'] = emailController.text;

      if (_selectedImage != null) {
        request.files.add(await http.MultipartFile.fromPath('image', _selectedImage!.path));
      }

      try {
        final response = await request.send();
        final responseData = await http.Response.fromStream(response);
        final jsonResponse = json.decode(responseData.body);

        if (jsonResponse['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Profile updated successfully');
          Navigator.pop(context);
        } else {
          Fluttertoast.showToast(msg: 'Failed to update profile');
        }
      } catch (e) {
        Fluttertoast.showToast(msg: 'Error: $e');
      }
    }
  }
}
