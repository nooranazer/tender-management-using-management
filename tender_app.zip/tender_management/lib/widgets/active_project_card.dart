// import 'package:ecobin/AgentChangePassword.dart';
// import 'package:ecobin/AgentViewAssignedWork.dart';
// import 'package:ecobin/AgentViewComplaint.dart';
// import 'package:ecobin/AgentViewNotifications.dart';
// import 'package:ecobin/login.dart';
import 'package:flutter/material.dart';
import 'package:percent_indicator/percent_indicator.dart';
import 'package:untitled_eco/AgentChangePassword.dart';
import 'package:untitled_eco/AgentViewAssignedWork.dart';
import 'package:untitled_eco/AgentViewComplaint.dart';
import 'package:untitled_eco/AgentViewNotifications.dart';
import 'package:untitled_eco/login.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: AgentHomePage(),
    );
  }
}

class AgentHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: Text('Active Projects'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Your Projects',
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Colors.teal,
              ),
            ),
            // SizedBox(height: 20),
            // Row(
            //   children: [
            //     ActiveProjectsCard(
            //       cardColor: Colors.transparent,
            //       loadingPercent: 0.25,
            //       title: 'Medical App',
            //       subtitle: '9 hours progress',
            //       backgroundImage: 'assets/medical_app.jpg',
            //     ),
            //     SizedBox(width: 16),
            //     ActiveProjectsCard(
            //       cardColor: Colors.transparent,
            //       loadingPercent: 0.6,
            //       title: 'History Notes',
            //       subtitle: '20 ..........hours progress',
            //       backgroundImage: 'assets/history_notes.jpg',
            //     ),
            //   ],
            // ),
            // SizedBox(height: 16),
            // Row(
            //   children: [
            //     ActiveProjectsCard(
            //       cardColor: Colors.transparent,
            //       loadingPercent: 0.45,
            //       title: 'Sports App',
            //       subtitle: '5 hours progress',
            //       backgroundImage: 'assets/sports_app.jpg',
            //     ),
            //     SizedBox(width: 16),
            //     ActiveProjectsCard(
            //       cardColor: Colors.transparent,
            //       loadingPercent: 0.9,
            //       title: 'Flutter Course',
            //       subtitle: '23 hours progress',
            //       backgroundImage: 'assets/agenthome.jpg',
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}

class ActiveProjectsCard extends StatelessWidget {
  final Color cardColor;
  final double loadingPercent;
  final String title;
  final String subtitle;
  final String? backgroundImage;

  ActiveProjectsCard({
    required this.cardColor,
    required this.loadingPercent,
    required this.title,
    required this.subtitle,
    this.backgroundImage,
  });

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: 1,
      child: GestureDetector(
        onTap: () {

          if (title== "Work"){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AgentViewAssignedWork()),
            );
          }
          else if(title == "Complaints"){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AgentViewComplaints()),
            );
          }else if(title == "Notifications"){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const AgentNotificationScreen()),
            );
          }else if(title == "ChangePassword"){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AgentChangePassword()),
            );
          }else if(title == "Logout"){
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const LoginPage()),
            );
          }
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Clicked on $title')),
          );
        },
        child: Container(
          margin: EdgeInsets.symmetric(vertical: 10.0),
          padding: EdgeInsets.all(15.0),
          height: 200,
          width: 180,
          decoration: BoxDecoration(
            color: cardColor,
            borderRadius: BorderRadius.circular(0.0),
            image: backgroundImage != null
                ? DecorationImage(
              image: AssetImage(backgroundImage!),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                Colors.black.withOpacity(0.3),
                BlendMode.darken,
              ),
            )
                : null,
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,  // Centers content vertically
            crossAxisAlignment: CrossAxisAlignment.center,  // Centers content horizontally

            children: <Widget>[
              Padding(
                padding: const EdgeInsets.all(10.0),
                child: CircularPercentIndicator(
                  animation: true,
                  radius: 55.0,
                  percent: loadingPercent,
                  lineWidth: 5.0,
                  circularStrokeCap: CircularStrokeCap.round,
                  backgroundColor: Colors.white10,
                  progressColor: Colors.white,
                  // center: Text(
                  //   '${(loadingPercent * 100).round()}%',
                  //   style: TextStyle(
                  //       fontWeight: FontWeight.w700, color: Colors.white),
                  // ),

                  center: Image.asset(
                    'assets/agenthome.jpg', // Replace with your image path
                    width: 30.0, // Adjust the size as needed
                    height: 30.0,
                  ),
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 15.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,

                    ),
                    textAlign: TextAlign.center,

                  ),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontSize: 12.0,
                      color: Colors.white54,
                      fontWeight: FontWeight.w400,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
