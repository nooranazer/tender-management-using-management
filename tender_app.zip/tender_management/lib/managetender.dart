// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:tender_management/edittender.dart';
//
// import 'package:url_launcher/url_launcher.dart';
// import 'package:path_provider/path_provider.dart';
// import 'package:dio/dio.dart'; // For downloading files
//
// class managetendr extends StatelessWidget {
//   const managetendr({Key? key}) : super(key: key);
//
//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       title: 'Tender Management',
//       theme: ThemeData(
//         primarySwatch: Colors.blueGrey,
//       ),
//       home: const managetender(title: 'Manage Tenders'),
//     );
//   }
// }
//
// class managetender extends StatefulWidget {
//   const managetender({Key? key, required this.title}) : super(key: key);
//
//   final String title;
//
//   @override
//   State<managetender> createState() => _ViewBusUserPageState();
// }
//
// class _ViewBusUserPageState extends State<managetender> {
//   List<String> cid_ = <String>[];
//   List<String> cname_ = <String>[];
//   List<String> cunit_ = <String>[];
//   List<String> cbrand_ = <String>[];
//   List<String> cphone_ = <String>[];
//   List<String> cshop_ = <String>[];
//   List<String> cimage_ = <String>[];
//
//   @override
//   void initState() {
//     super.initState();
//     viewProducts();
//   }
//
//   Future<void> viewProducts() async {
//     List<String> cid = <String>[];
//     List<String> cname = <String>[];
//     List<String> cunit = <String>[];
//     List<String> cbrand = <String>[];
//     List<String> cphone = <String>[];
//     List<String> cshop = <String>[];
//     List<String> cimage = <String>[];
//
//     try {
//       final pref = await SharedPreferences.getInstance();
//       String ip = pref.getString("url") ?? '';
//       String lid = pref.getString("lid") ?? '';
//       String url = ip + "contractortender_view";
//
//       var data = await http.post(Uri.parse(url), body: {'lid': lid});
//       var jsondata = json.decode(data.body);
//       var arr = jsondata["data"];
//
//       for (int i = 0; i < arr.length; i++) {
//         cid.add(arr[i]['id'].toString());
//         cname.add(arr[i]['name'].toString());
//         cunit.add(arr[i]['description'].toString());
//         cbrand.add(arr[i]['lastdate'].toString());
//         cphone.add(arr[i]['min_max'].toString());
//         cshop.add(arr[i]['status'].toString());
//         cimage.add(arr[i]['document'].toString());
//       }
//
//       setState(() {
//         cimage_ = cimage;
//         cid_ = cid;
//         cname_ = cname;
//         cunit_ = cunit;
//         cbrand_ = cbrand;
//         cshop_ = cshop;
//         cphone_ = cphone;
//       });
//     } catch (e) {
//       print("Error: $e");
//     }
//   }
//
//   Future<void> deleteTender(String tenderId) async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       String ip = prefs.getString("url") ?? '';
//       String url = ip + "contrctortender_delete";
//
//       var response = await http.post(Uri.parse(url), body: {'tid': tenderId});
//       var responseData = json.decode(response.body);
//
//       if (response.statusCode == 200 && responseData['status'] == 'ok') {
//         Fluttertoast.showToast(msg: 'Tender deleted successfully');
//         viewProducts(); // Reload the tenders list after deletion
//       } else {
//         Fluttertoast.showToast(msg: 'Error deleting tender');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Network Error: $e');
//     }
//   }
//
//   Future<void> downloadDocument(String url) async {
//     try {
//       Dio dio = Dio();
//       var dir = await getApplicationDocumentsDirectory();
//       String filePath = "${dir.path}/document.pdf"; // Change the extension if needed
//       await dio.download(url, filePath);
//       Fluttertoast.showToast(msg: 'Download complete: $filePath');
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Error downloading file: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text("Manage Tenders", style: TextStyle(color: Colors.white)),
//         backgroundColor: Colors.teal,
//       ),
//       body: ListView.builder(
//         itemCount: cid_.length,
//         itemBuilder: (BuildContext context, int index) {
//           return Card(
//             margin: EdgeInsets.all(10),
//             elevation: 8,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   GestureDetector(
//                     onTap: () {
//                       // Image clicked - Download the document
//                       downloadDocument(cimage_[index]);
//                     },
//                     child: Container(
//                       height: 200,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(12),
//                         image: DecorationImage(
//                           image: NetworkImage(cimage_[index]),
//                           fit: BoxFit.cover,
//                         ),
//                       ),
//                     ),
//                   ),
//                   SizedBox(height: 12),
//                   Text(
//                     cname_[index],
//                     style: TextStyle(
//                       fontSize: 22,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   SizedBox(height: 6),
//                   Text("Description: ${cunit_[index]}", style: TextStyle(fontSize: 16)),
//                   Text("Last Date: ${cbrand_[index]}", style: TextStyle(fontSize: 16)),
//                   Text("Price: ${cphone_[index]}", style: TextStyle(fontSize: 16)),
//                   Text("Status: ${cshop_[index]}", style: TextStyle(fontSize: 16)),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.end,
//                     children: [
//                       IconButton(
//                         icon: Icon(Icons.edit, color: Colors.blue),
//                         onPressed: () async {
//                           final pref = await SharedPreferences.getInstance();
//                           await pref.setString("tid",cid_[index]);
//
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => EditProfile(),  // Navigate to the Edit Profile Page
//                             ),
//                           );
//                           // Implement your edit logic here
//                         },
//                       ),
//                       IconButton(
//                         icon: Icon(Icons.delete, color: Colors.red),
//                         onPressed: () {
//                           showDialog(
//                             context: context,
//                             builder: (BuildContext context) {
//                               return AlertDialog(
//                                 title: Text("Delete Tender"),
//                                 content: Text("Are you sure you want to delete this tender?"),
//                                 actions: [
//                                   TextButton(
//                                     onPressed: () {
//                                       Navigator.of(context).pop();
//                                     },
//                                     child: Text("Cancel"),
//                                   ),
//                                   TextButton(
//                                     onPressed: () {
//                                       deleteTender(cid_[index]);
//                                       Navigator.of(context).pop();
//                                     },
//                                     child: Text("Delete"),
//                                   ),
//                                 ],
//                               );
//                             },
//                           );
//                         },
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//     );
//   }
// }


///secondcode

// import 'dart:convert';
// import 'dart:io';
//
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:tender_management/edittender.dart';
// import 'package:tender_management/addtender.dart'; // Add Tender Page
// import 'package:path_provider/path_provider.dart';
// import 'package:dio/dio.dart';
// import 'package:tender_management/tenderreq.dart';
//
// class ManageTender extends StatefulWidget {
//   const ManageTender({Key? key}) : super(key: key);
//
//   @override
//   State<ManageTender> createState() => _ManageTenderState();
// }
//
// class _ManageTenderState extends State<ManageTender> {
//   List<String> cid_ = <String>[];
//   List<String> cname_ = <String>[];
//   List<String> cunit_ = <String>[];
//   List<String> cbrand_ = <String>[];
//   List<String> cphone_ = <String>[];
//   List<String> cshop_ = <String>[];
//   List<String> cimage_ = <String>[];
//
//   @override
//   void initState() {
//     super.initState();
//     viewProducts();
//   }
//
//   Future<void> viewProducts() async {
//     try {
//       final pref = await SharedPreferences.getInstance();
//       String ip = pref.getString("url") ?? '';
//       String lid = pref.getString("lid") ?? '';
//       String url = ip + "contractortender_view";
//
//       var data = await http.post(Uri.parse(url), body: {'lid': lid});
//       var jsondata = json.decode(data.body);
//       var arr = jsondata["data"];
//
//       setState(() {
//         cid_ = arr.map<String>((item) => item['id'].toString()).toList();
//         cname_ = arr.map<String>((item) => item['name'].toString()).toList();
//         cunit_ = arr.map<String>((item) => item['description'].toString()).toList();
//         cbrand_ = arr.map<String>((item) => item['lastdate'].toString()).toList();
//         cphone_ = arr.map<String>((item) => item['min_max'].toString()).toList();
//         cshop_ = arr.map<String>((item) => item['status'].toString()).toList();
//         cimage_ = arr.map<String>((item) => item['document'].toString()).toList();
//       });
//     } catch (e) {
//       Fluttertoast.showToast(msg: "Error loading tenders: $e");
//     }
//   }
//
//   Future<void> deleteTender(String tenderId) async {
//     try {
//       final prefs = await SharedPreferences.getInstance();
//       String ip = prefs.getString("url") ?? '';
//       String url = ip + "contrctortender_delete";
//
//       var response = await http.post(Uri.parse(url), body: {'tid': tenderId});
//       var responseData = json.decode(response.body);
//
//       if (response.statusCode == 200 && responseData['status'] == 'ok') {
//         Fluttertoast.showToast(msg: 'Tender deleted successfully');
//         viewProducts(); // Reload the tenders list after deletion
//       } else {
//         Fluttertoast.showToast(msg: 'Error deleting tender');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Network Error: $e');
//     }
//   }
//
//   Future<void> downloadDocument(String url) async {
//     try {
//       Dio dio = Dio();
//       var dir = await getApplicationDocumentsDirectory();
//       String filePath = "${dir.path}/document.pdf"; // Change the extension if needed
//       await dio.download(url, filePath);
//       Fluttertoast.showToast(msg: 'Download complete: $filePath');
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Error downloading file: $e');
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Manage Tenders"),
//         backgroundColor: Colors.teal,
//         leading: IconButton(
//           icon: const Icon(Icons.arrow_back),
//           onPressed: () {
//             Navigator.pop(context); // Go back to the previous page
//           },
//         ),
//       ),
//       body: cid_.isEmpty
//           ? const Center(child: CircularProgressIndicator())
//           : ListView.builder(
//         itemCount: cid_.length,
//         itemBuilder: (BuildContext context, int index) {
//           return Card(
//             margin: const EdgeInsets.all(10),
//             elevation: 8,
//             shape: RoundedRectangleBorder(
//               borderRadius: BorderRadius.circular(12),
//             ),
//             child: Padding(
//               padding: const EdgeInsets.all(10.0),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   GestureDetector(
//                     onTap: () {
//                       // Image clicked - Download the document
//                       downloadDocument(cimage_[index]);
//                     },
//                     child: Container(
//                       height: 200,
//                       width: double.infinity,
//                       decoration: BoxDecoration(
//                         borderRadius: BorderRadius.circular(12),
//                         image: DecorationImage(
//                           image: NetworkImage(cimage_[index]),
//                           fit: BoxFit.cover,
//                         ),
//                       ),
//                     ),
//                   ),
//                   const SizedBox(height: 12),
//                   Text(
//                     cname_[index],
//                     style: const TextStyle(
//                       fontSize: 22,
//                       fontWeight: FontWeight.bold,
//                     ),
//                   ),
//                   const SizedBox(height: 6),
//                   Text("Description: ${cunit_[index]}", style: const TextStyle(fontSize: 16)),
//                   Text("Last Date: ${cbrand_[index]}", style: const TextStyle(fontSize: 16)),
//                   Text("Price: ${cphone_[index]}", style: const TextStyle(fontSize: 16)),
//                   Text("Status: ${cshop_[index]}", style: const TextStyle(fontSize: 16)),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.end,
//                     children: [
//
//                       IconButton(
//                         icon: const Icon(Icons.edit, color: Colors.blue),
//                         onPressed: () async {
//                           final pref = await SharedPreferences.getInstance();
//                           await pref.setString("tid", cid_[index]);
//
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => EditTender(),
//                             ),
//                           );
//                         },
//                       ),
//                       IconButton(
//                         icon: const Icon(Icons.delete, color: Colors.red),
//                         onPressed: () {
//                           showDialog(
//                             context: context,
//                             builder: (BuildContext context) {
//                               return AlertDialog(
//                                 title: const Text("Delete Tender"),
//                                 content: const Text("Are you sure you want to delete this tender?"),
//                                 actions: [
//                                   TextButton(
//                                     onPressed: () {
//                                       Navigator.of(context).pop();
//                                     },
//                                     child: const Text("Cancel"),
//                                   ),
//                                   TextButton(
//                                     onPressed: () {
//                                       deleteTender(cid_[index]);
//                                       Navigator.of(context).pop();
//                                     },
//                                     child: const Text("Delete"),
//                                   ),
//                                 ],
//                               );
//                             },
//                           );
//                         },
//                       ),
//                       IconButton(
//                         icon: const Icon(Icons.more, color: Colors.blue),
//                         onPressed: () async {
//                           final pref = await SharedPreferences.getInstance();
//                           await pref.setString("tid", cid_[index]);
//                           await pref.setString("amount", cphone_[index]);
//
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                               builder: (context) => tenderreq(),
//                             ),
//                           );
//                         },
//                       ),
//                     ],
//                   ),
//                 ],
//               ),
//             ),
//           );
//         },
//       ),
//       floatingActionButton: FloatingActionButton(
//         onPressed: () {
//           Navigator.push(
//             context,
//             MaterialPageRoute(
//               builder: (context) => const AddDocument(title: '',),
//             ),
//           );
//         },
//         tooltip: 'Add Tender',
//         child: const Icon(Icons.add),
//       ),
//     );
//   }
// }






import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tender_management/edittender.dart';
import 'package:tender_management/addtender.dart';
import 'package:path_provider/path_provider.dart';
import 'package:dio/dio.dart';
import 'package:tender_management/tenderreq.dart';

import 'UserHome.dart';

class ManageTender extends StatefulWidget {
  const ManageTender({Key? key}) : super(key: key);

  @override
  State<ManageTender> createState() => _ManageTenderState();
}

class _ManageTenderState extends State<ManageTender> {
  List<String> cid_ = <String>[];
  List<String> cname_ = <String>[];
  List<String> cunit_ = <String>[];
  List<String> cbrand_ = <String>[];
  List<String> cphone_ = <String>[];
  List<String> cshop_ = <String>[];
  List<String> cimage_ = <String>[];

  @override
  void initState() {
    super.initState();
    viewProducts();
  }

  Future<void> viewProducts() async {
    try {
      final pref = await SharedPreferences.getInstance();
      String ip = pref.getString("url") ?? '';
      String lid = pref.getString("lid") ?? '';
      String url = ip + "contractortender_view";

      var data = await http.post(Uri.parse(url), body: {'lid': lid});
      var jsondata = json.decode(data.body);
      var arr = jsondata["data"];

      setState(() {
        cid_ = arr.map<String>((item) => item['id'].toString()).toList();
        cname_ = arr.map<String>((item) => item['name'].toString()).toList();
        cunit_ = arr.map<String>((item) => item['description'].toString()).toList();
        cbrand_ = arr.map<String>((item) => item['lastdate'].toString()).toList();
        cphone_ = arr.map<String>((item) => item['min_max'].toString()).toList();
        cshop_ = arr.map<String>((item) => item['status'].toString()).toList();
        cimage_ = arr.map<String>((item) => item['document'].toString()).toList();
      });
    } catch (e) {
      Fluttertoast.showToast(msg: "Error loading tenders: $e");
    }
  }

  Future<void> deleteTender(String tenderId) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String ip = prefs.getString("url") ?? '';
      String url = ip + "contrctortender_delete";

      var response = await http.post(Uri.parse(url), body: {'tid': tenderId});
      var responseData = json.decode(response.body);

      if (response.statusCode == 200 && responseData['status'] == 'ok') {
        Fluttertoast.showToast(msg: 'Tender deleted successfully');
        viewProducts();
      } else {
        Fluttertoast.showToast(msg: 'Error deleting tender');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Network Error: $e');
    }
  }

  Future<void> downloadDocument(String url) async {
    try {
      Dio dio = Dio();
      var dir = await getApplicationDocumentsDirectory();
      String filePath = "${dir.path}/document.pdf";
      await dio.download(url, filePath);
      Fluttertoast.showToast(msg: 'Download complete: $filePath');
    } catch (e) {
      Fluttertoast.showToast(msg: 'Error downloading file: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Manage Tenders"),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Colors.teal, Colors.green],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
          ),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => UserHomePage()),
            );
          },
        ),
      ),
      body: cid_.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: cid_.length,
        itemBuilder: (BuildContext context, int index) {
          return Card(
            margin: const EdgeInsets.all(10),
            elevation: 8,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            child: Padding(
              padding: const EdgeInsets.all(10.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                    onTap: () {
                      downloadDocument(cimage_[index]);
                    },
                    child: Container(
                      height: 200,
                      width: double.infinity,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(12),
                        image: DecorationImage(
                          image: NetworkImage(cimage_[index]),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    cname_[index],
                    style: const TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text("Description: ${cunit_[index]}", style: const TextStyle(fontSize: 16)),
                  Text("Last Date: ${cbrand_[index]}", style: const TextStyle(fontSize: 16)),
                  Text("Price: ${cphone_[index]}", style: const TextStyle(fontSize: 16)),
                  Text("Status: ${cshop_[index]}", style: const TextStyle(fontSize: 16)),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.edit, color: Colors.blue),
                        onPressed: () async {
                          final pref = await SharedPreferences.getInstance();
                          await pref.setString("tid", cid_[index]);

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => EditTender(),
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                title: const Text("Delete Tender"),
                                content: const Text("Are you sure you want to delete this tender?"),
                                actions: [
                                  TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Cancel"),
                                  ),
                                  TextButton(
                                    onPressed: () {
                                      deleteTender(cid_[index]);
                                      Navigator.of(context).pop();
                                    },
                                    child: const Text("Delete"),
                                  ),
                                ],
                              );
                            },
                          );
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.more_horiz, color: Colors.blue),
                        onPressed: () async {
                          final pref = await SharedPreferences.getInstance();
                          await pref.setString("tid", cid_[index]);
                          await pref.setString("amount", cphone_[index]);

                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => tenderreq(),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddDocument(title: '',),
            ),
          );
        },
        tooltip: 'Add Tender',
        child: const Icon(Icons.add),
      ),
    );
  }
}
