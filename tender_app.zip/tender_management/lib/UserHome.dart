// import 'dart:async';
// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:tender_management/complaint.dart';
// import 'package:tender_management/managetender.dart';
// import 'package:tender_management/ongoingtender.dart';
// import 'package:tender_management/pasttender.dart';
// import 'package:tender_management/profile.dart';
// import 'package:tender_management/theme/colors/light_colors.dart';
// import 'package:tender_management/userpayment.dart';
// import 'package:tender_management/widgets/task_column.dart';
//
// import 'login.dart';
//
//
// class UserHomePage extends StatefulWidget {
//   @override
//   _UserHomePageState createState() => _UserHomePageState();
// }
//
// class _UserHomePageState extends State<UserHomePage> {
//
//   Map<String, dynamic>? userProfile;
//   String imgpath = "";
//   String lastid = "0";
//   late Timer _timer; // Timer for periodic updates
//   @override
//   void initState() {
//     print("started");
//     super.initState();
//     fetchUserProfile();
//   }
//
//   // _UserHomePageState()  {
//   //   print("started");
//   //   // Call the server every 30 seconds
//   //   _timer = Timer.periodic(const Duration(seconds: 60), (timer) async {
//   //     _fetchMessageCount();
//   //
//   //
//   //
//   //
//   //   });
//   //
//   //
//   //   // Fetch the initial message count immediately
//   //   _fetchMessageCount();
//   //
//   // }
//   // void requestNotificationPermission() {
//   //   AwesomeNotifications().isNotificationAllowed().then((isAllowed) {
//   //     if (!isAllowed) {
//   //       // Request permission
//   //       AwesomeNotifications().requestPermissionToSendNotifications();
//   //     }
//   //   });
//   // }
//   // void stopTimer() {
//   //   _timer?.cancel(); // Cancel the timer
//   //   // _timer = null;    // Optional: Set the timer to null for clarity
//   // }
//   // void showBasicNotification() {
//   //   print("Started===noti");
//   //   AwesomeNotifications().createNotification(
//   //     content: NotificationContent(
//   //       id: 1, // Unique ID for the notification
//   //       channelKey: 'basic_channel', // Channel key from initialization
//   //       title: 'Hello, World!', // Notification title
//   //       body: 'This is a basic notification from Awesome Notifications.', // Notification body
//   //       notificationLayout: NotificationLayout.Default,
//   //     ),
//   //   );
//   // }
//
//
//
//   // Future<void> _fetchMessageCount() async {
//   //   print("countmsg");
//   //   SharedPreferences prefs = await SharedPreferences.getInstance();
//   //   String? urls = prefs.getString('url');
//   //
//   //
//   //
//   //
//   //   final sh = await SharedPreferences.getInstance();
//   //   String url = sh.getString("url") ?? "";
//   //
//   //   try {
//   //     var data = await http.post(
//   //       Uri.parse(url + "agent_view_pickup_requests_nott"),
//   //       body: {'lid': sh.getString("lid").toString(),"lastid":lastid},
//   //     );
//   //     var jsonData = jsonDecode(data.body);
//   //     String status = jsonData['status'].toString();
//   //
//   //     if (status == "ok") {
//   //       showBasicNotification();
//   //       ScaffoldMessenger.of(context).showSnackBar(
//   //         SnackBar(content: Text("Welcome"), duration: Duration(seconds: 4)),
//   //       );
//   //
//   //       String lid = jsonData['lastid'].toString();
//   //       lastid=lid;
//   //       // sh.setString("lid", lid);
//   //
//   //
//   //     } else {
//   //
//   //     }
//   //   } catch (e) {
//   //     print(e);
//   //   }
//   //     }
//
//   Future<void> fetchUserProfile() async {
//     final sh = await SharedPreferences.getInstance();
//     String url = sh.getString("url") ?? "";
//
//     try {
//       final response = await http.post(
//         Uri.parse(url + "and_user_view_profile"),
//         body: {'lid': sh.getString("lid").toString()},
//       );
//
//       if (response.statusCode == 200) {
//         setState(() {
//           userProfile = json.decode(response.body);
//           imgpath = sh.getString("imgurl").toString();
//         });
//       } else {
//         throw Exception('Failed to load user profile');
//       }
//     } catch (e) {
//       print('Error: $e');
//     }
//   }
//
//   // Text subheading(String title) {
//   //   return Text(
//   //     title,
//   //     style: TextStyle(
//   //       color: LightColors.kDarkBlue,
//   //       fontSize: 20.0,
//   //       fontWeight: FontWeight.w700,
//   //       letterSpacing: 1.2,
//   //     ),
//   //   );
//   // }
//
//   @override
//   Widget build(BuildContext context) {
//     double width = MediaQuery.of(context).size.width;
//
//     return WillPopScope(
//       onWillPop: () async {
//         Navigator.push(
//           context,
//           MaterialPageRoute(builder: (context) => UserHomePage()),
//         );
//         return false;
//       },
//       child: Scaffold(
//         backgroundColor: Colors.white,
//         body: SafeArea(
//           child: Column(
//             children: [
//               // Top Container for user profile and header
//               Container(
//                 height: 250,
//                 width: width,
//                 padding: EdgeInsets.zero,
//                 decoration: BoxDecoration(
//                   color: Colors.teal,
//                   borderRadius: BorderRadius.only(
//                     bottomLeft: Radius.circular(20.0),
//                     bottomRight: Radius.circular(20.0),
//                   ),
//                 ),
//                 child: userProfile == null
//                     ? Center(child: CircularProgressIndicator())
//                     : Column(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     CircleAvatar(
//                       backgroundColor: Colors.white,
//                       radius: 45.0,
//                       backgroundImage:
//                       NetworkImage(imgpath + userProfile!['img']),
//                     ),
//                     SizedBox(height: 10),
//                     Text(
//                       userProfile!['name'] ?? 'User Name',
//                       style: TextStyle(
//                         fontSize: 22.0,
//                         color: Colors.white,
//                         fontWeight: FontWeight.w700,
//                       ),
//                     ),
//                     Text(
//                       userProfile!['email'] ?? 'user@example.com',
//                       style: TextStyle(
//                         fontSize: 16.0,
//                         color: Colors.white70,
//                       ),
//                     ),
//                   ],
//                 ),
//               ),
//               // Task Section
//               // Container(
//               //   padding: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
//               //   child: Column(
//               //     children: <Widget>[
//               //       Row(
//               //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//               //         children: <Widget>[
//               //           subheading('My Tasks'),
//               //           GestureDetector(
//               //             onTap: () {
//               //               // Navigator.push(
//               //               //   context,
//               //               //   MaterialPageRoute(
//               //               //       builder: (context) => UserViewCartItemsPage()),
//               //               // );
//               //             },
//               //             child: Icon(
//               //               Icons.add_shopping_cart,
//               //               size: 30.0,
//               //               color: Colors.green,
//               //             ),
//               //           ),
//               //         ],
//               //       ),
//               //       SizedBox(height: 15.0),
//               //       Row(
//               //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//               //         children: [
//               //           Expanded(
//               //             child: TaskColumn(
//               //               icon: Icons.list_alt,
//               //               iconBackgroundColor: Colors.purple,
//               //               title: 'Total',
//               //               subtitle: userProfile?["total_count"] ?? "0",
//               //             ),
//               //           ),
//               //           Expanded(
//               //             child: TaskColumn(
//               //               icon: Icons.alarm,
//               //               iconBackgroundColor: LightColors.kRed,
//               //               title: 'To Do',
//               //               subtitle: userProfile?["pen_count"] ?? "0",
//               //             ),
//               //           ),
//               //           Expanded(
//               //             child: TaskColumn(
//               //               icon: Icons.check_circle_outline,
//               //               iconBackgroundColor: LightColors.kBlue,
//               //               title: 'Done',
//               //               subtitle: userProfile?["com_count"] ?? "0",
//               //             ),
//               //           ),
//               //         ],
//               //       ),
//               //     ],
//               //   ),
//               // ),
//               // Navigation Grid
//               Expanded(
//                 child: Padding(
//                   padding: const EdgeInsets.all(16.0),
//                   child: GridView.count(
//                     crossAxisCount: 2,
//                     crossAxisSpacing: 16.0,
//                     mainAxisSpacing: 16.0,
//                     children: [
//                       _buildGridItem(
//                         icon: Icons.person,
//                         title: 'Profile',
//                         onTap: () {
//                            Navigator.push(
//                              context,
//                              MaterialPageRoute(
//                                  builder: (context) => ProfilePage()),
//                            );
//                         },
//                       ),
//                       _buildGridItem(
//                         icon: Icons.work,
//                         title: 'managetender',
//                         onTap: () {
//                           Navigator.push(
//                               context,
//                               MaterialPageRoute(
//                               builder: (context) =>
//                           const ManageTender()),
//                           );
//
//                         }
//                       ),
//                       _buildGridItem(
//                         icon: Icons.work_history_rounded,
//                         title: 'Ongoing tender',
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) =>  ongoingtender()),
//                           );
//                         },
//                       ),
//                       _buildGridItem(
//                         icon: Icons.folder,
//                         title: 'past tender',
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => pasttender()),
//                           );
//                         },
//                       ),
//                       // _buildGridItem(
//                       //   icon: Icons.report_problem,
//                       //   title: 'Complaints',
//                       //   onTap: () {
//                       //     // Navigator.push(
//                       //     //   context,
//                       //     //   MaterialPageRoute(
//                       //     //       builder: (context) => const UserViewComplaint()),
//                       //     // );
//                       //   },
//                       // ),
//                       _buildGridItem(
//                         icon: Icons.security,
//                         title: 'Complaint',
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(
//                                 builder: (context) => AppComplaint()),
//                           );
//                         },
//                       ),
//                       // _buildGridItem(
//                       //   icon: Icons.report_problem_outlined,
//                       //   title: 'payment',
//                       //   onTap: () {
//                       //     Navigator.push(
//                       //       context,
//                       //       MaterialPageRoute(
//                       //           builder: (context) =>
//                       //           UserPaymentScreen()),
//                       //     );
//                       //   },
//                       // ),
//                       _buildGridItem(
//                         icon: Icons.logout,
//                         title: 'Logout',
//                         onTap: () {
//                           Navigator.push(
//                             context,
//                             MaterialPageRoute(builder: (context) => login()),
//                           );
//                         },
//                       ),
//                     ],
//                   ),
//                 ),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   Widget _buildGridItem({
//     required IconData icon,
//     required String title,
//     required Function() onTap,
//   }) {
//     return GestureDetector(
//       onTap: onTap,
//       child: Container(
//         decoration: BoxDecoration(
//           gradient: LinearGradient(
//             colors: [Colors.tealAccent.shade200, Colors.teal.shade500],
//             begin: Alignment.topLeft,
//             end: Alignment.bottomRight,
//           ),
//           borderRadius: BorderRadius.circular(16.0),
//           boxShadow: [
//             BoxShadow(
//               color: Colors.teal.withOpacity(0.2),
//               blurRadius: 10,
//               offset: Offset(5, 5),
//             ),
//             BoxShadow(
//               color: Colors.white.withOpacity(0.6),
//               blurRadius: 10,
//               offset: Offset(-5, -5),
//             ),
//           ],
//         ),
//         child: Column(
//           mainAxisAlignment: MainAxisAlignment.center,
//           children: [
//             Container(
//               padding: EdgeInsets.all(10.0),
//               decoration: BoxDecoration(
//                 color: Colors.white.withOpacity(0.8),
//                 shape: BoxShape.circle,
//                 boxShadow: [
//                   BoxShadow(
//                     color: Colors.grey.withOpacity(0.3),
//                     blurRadius: 5,
//                     offset: Offset(3, 3),
//                   ),
//                 ],
//               ),
//               child: Icon(
//                 icon,
//                 size: 50,
//                 color: Colors.teal.shade700,
//               ),
//             ),
//             SizedBox(height: 12),
//             Text(
//               title,
//               textAlign: TextAlign.center,
//               style: TextStyle(
//                 fontSize: 18.0,
//                 fontWeight: FontWeight.w700,
//                 color: Colors.white,
//                 letterSpacing: 1.2,
//               ),
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }


import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tender_management/complaint.dart';
import 'package:tender_management/managetender.dart';
import 'package:tender_management/ongoingtender.dart';
import 'package:tender_management/pasttender.dart';
import 'package:tender_management/profile.dart';
import 'package:tender_management/theme/colors/light_colors.dart';
import 'package:tender_management/userpayment.dart';
import 'package:tender_management/widgets/task_column.dart';
import 'login.dart';

class UserHomePage extends StatefulWidget {
  @override
  _UserHomePageState createState() => _UserHomePageState();
}

class _UserHomePageState extends State<UserHomePage> {
  Map<String, dynamic>? userProfile;
  String imgpath = "";
  String lastid = "0";
  late Timer _timer;

  @override
  void initState() {
    super.initState();
    fetchUserProfile();
  }

  Future<void> fetchUserProfile() async {
    final sh = await SharedPreferences.getInstance();
    String url = sh.getString("url") ?? "";

    try {
      final response = await http.post(
        Uri.parse(url + "and_user_view_profile"),
        body: {'lid': sh.getString("lid").toString()},
      );

      if (response.statusCode == 200) {
        setState(() {
          userProfile = json.decode(response.body);
          imgpath = sh.getString("imgurl").toString();
        });
      } else {
        throw Exception('Failed to load user profile');
      }
    } catch (e) {
      print('Error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    double width = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(
        title: Text(" Home page"),
        backgroundColor: Colors.teal,
      ),
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: <Widget>[
            UserAccountsDrawerHeader(
              accountName: Text(userProfile?['name'] ?? 'User Name'),
              accountEmail: Text(userProfile?['email'] ?? 'user@example.com'),
              currentAccountPicture: CircleAvatar(
                backgroundColor: Colors.white,
                backgroundImage: NetworkImage(imgpath + (userProfile?['img'] ?? '')),
              ),
              decoration: BoxDecoration(
                color: Colors.teal,
              ),
            ),
            _buildDrawerItem(Icons.person, "Profile", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => ProfilePage()),
              );
            }),
            _buildDrawerItem(Icons.logout, "Logout", () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => login()),
              );
            }),
          ],
        ),
      ),
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            // Container(
            //   height: 250,
            //   width: width,
              // decoration: BoxDecoration(
              //   color: Colors.teal,
              //   borderRadius: BorderRadius.only(
              //     bottomLeft: Radius.circular(20.0),
              //     bottomRight: Radius.circular(20.0),
              //   ),
              // ),
              // child: userProfile == null
              //     ? Center(child: CircularProgressIndicator())
              //     : Column(
              //   mainAxisAlignment: MainAxisAlignment.center,
                // children: [
                //   CircleAvatar(
                //     backgroundColor: Colors.white,
                //     radius: 45.0,
                //     backgroundImage: NetworkImage(imgpath + userProfile!['img']),
                //   ),
                //   SizedBox(height: 10),
                //   Text(
                //     userProfile!['name'] ?? 'User Name',
                //     style: TextStyle(
                //       fontSize: 22.0,
                //       color: Colors.white,
                //       fontWeight: FontWeight.w700,
                //     ),
                //   ),
                //   Text(
                //     userProfile!['email'] ?? 'user@example.com',
                //     style: TextStyle(
                //       fontSize: 16.0,
                //       color: Colors.white70,
                //     ),
                //   ),
                // ],
              // ),
            // ),
            Expanded(
              child: GridView.count(
                crossAxisCount: 2,
                padding: EdgeInsets.all(10),
                children: [
                  _buildGridItem(Icons.work, "Manage Tenders", ManageTender()),
                  _buildGridItem(Icons.work_history_rounded, "Ongoing Tenders", ongoingtender()),
                  _buildGridItem(Icons.folder, "Past Tenders", pasttender()),
                  _buildGridItem(Icons.security, "Complaints", AppComplaint()),
                  // _buildGridItem(Icons.payment, "Payments", userpayment()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDrawerItem(IconData icon, String title, Function() onTap) {
    return ListTile(
      leading: Icon(icon, color: Colors.teal),
      title: Text(title),
      onTap: onTap,
    );
  }

  Widget _buildGridItem(IconData icon, String title, Widget page) {
    return Card(
      elevation: 5,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: InkWell(
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => page),
          );
        },
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 50, color: Colors.teal),
            SizedBox(height: 10),
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }
}
