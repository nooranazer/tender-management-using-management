





// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
// import 'Home.dart';

// class AddDocument extends StatefulWidget {
//   const AddDocument({super.key, required this.title});
//
//   final String title;
//
//   @override
//   State<AddDocument> createState() => _AddDocumentState();
// }
//
// class _AddDocumentState extends State<AddDocument> {
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController descriptionController = TextEditingController();
//   final TextEditingController dateController = TextEditingController();
//   final TextEditingController priceController = TextEditingController();
//   File? _image;
//   final _formKey = GlobalKey<FormState>();
//
//   // Method to pick an image from the gallery or camera
//   Future<void> _pickImage() async {
//     final picker = ImagePicker();
//     final pickedFile = await picker.pickImage(source: ImageSource.gallery);
//
//     if (pickedFile != null) {
//       setState(() {
//         _image = File(pickedFile.path);
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         title: const Text("Back"),
//       ),
//       body: SafeArea(
//         child: Form(
//           key: _formKey,
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 const Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: Align(
//                     alignment: Alignment.center,
//                     child: Text(
//                       "ADD TENDER",
//                       style: TextStyle(
//                         fontSize: 25,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.brown,
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: nameController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Name",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter your first name';
//                       }
//                       return null; // Return null if the input is valid
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: descriptionController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Description",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter a description';
//                       }
//                       return null; // Return null if the input is valid
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: dateController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Select last date",
//                       suffixIcon: Icon(Icons.calendar_today),
//                     ),
//                     readOnly: true, // Make the field read-only so users can only select a date from the picker
//                     onTap: () async {
//                       DateTime? pickedDate = await showDatePicker(
//                         context: context,
//                         initialDate: DateTime.now(),
//                         firstDate: DateTime(1900),
//                         lastDate: DateTime(2101),
//                       );
//
//                       if (pickedDate != null) {
//                         setState(() {
//                           dateController.text = "${pickedDate.toLocal()}".split(' ')[0]; // Format as "YYYY-MM-DD"
//                         });
//                       }
//                     },
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please select a date';
//                       }
//                       return null;
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: priceController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Price",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter a price';
//                       }
//                       return null; // Return null if the input is valid
//                     },
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 // Image picker button
//                 ElevatedButton.icon(
//                   onPressed: _pickImage,
//                   icon: const Icon(Icons.camera_alt),
//                   label: Text(_image == null ? 'Pick an Image' : 'Image Selected'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.lightGreen,
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 ElevatedButton(
//                   onPressed: () {
//                     if (_formKey.currentState!.validate() && _image != null) {
//                       _addDocument();
//                     } else {
//                       Fluttertoast.showToast(msg: 'Please fill in all fields and select an image');
//                     }
//                   },
//                   child: const Text('Add tender'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.lightGreen,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
//
//   // Method to send data to the backend
//   void _addDocument() async {
//     String details = descriptionController.text.trim();
//     String name = nameController.text.trim();
//
//     SharedPreferences sh = await SharedPreferences.getInstance();
//     String? url = sh.getString('url');
//     String? lid = sh.getString('lid');
//
//     if (url == null || lid == null) {
//       Fluttertoast.showToast(msg: 'Invalid configuration. Please try again.');
//       return;
//     }
//
//     final Uri apiUrl = Uri.parse(url + "contractrotender_add");
//
//     try {
//       // Prepare the request to send the data and the file
//       var request = http.MultipartRequest('POST', apiUrl)
//         ..fields['name'] = name
//         ..fields['desc'] = details
//         ..fields['lastdate'] = dateController.text // Using dateController text
//         ..fields['minmax'] = priceController.text // Using priceController text
//         ..fields['lid'] = lid;
//
//       // Attach the image file if it's selected
//       if (_image != null) {
//         var file = await http.MultipartFile.fromPath('files', _image!.path);
//         request.files.add(file);
//       }
//
//       var response = await request.send();
//
//       if (response.statusCode == 200) {
//         final responseData = await response.stream.bytesToString();
//         var data = jsonDecode(responseData);
//
//         if (data['status'] == 'ok') {
//           Fluttertoast.showToast(msg: 'Tender Added Successfully');
//           nameController.clear();
//           descriptionController.clear();
//           dateController.clear();
//           priceController.clear();
//           setState(() {
//             _image = null;
//           });
//           // Navigate to Home page and remove previous screens from stack
//           Navigator.pushAndRemoveUntil(
//             context,
//             MaterialPageRoute(builder: (context) => home()), // Navigate to Home
//                 (route) => false, // Remove all previous routes
//           );
//         } else {
//           Fluttertoast.showToast(msg: 'Error: tender not added.');
//         }
//       } else {
//         Fluttertoast.showToast(msg: 'Server Error: ${response.statusCode}');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Network Error: ${e.toString()}');
//     }
//   }
// }




// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:image_picker/image_picker.dart';
// import 'dart:io';
//
// class AddDocument extends StatefulWidget {
//   const AddDocument({super.key, required this.title});
//
//   final String title;
//
//   @override
//   State<AddDocument> createState() => _AddDocumentState();
// }
//
// class _AddDocumentState extends State<AddDocument> {
//   final TextEditingController nameController = TextEditingController();
//   final TextEditingController descriptionController = TextEditingController();
//   final TextEditingController dateController = TextEditingController();
//   final TextEditingController priceController = TextEditingController();
//   File? _image;
//   final _formKey = GlobalKey<FormState>();
//
//   // Method to pick an image from the gallery or camera
//   Future<void> _pickImage() async {
//     final picker = ImagePicker();
//     final pickedFile = await picker.pickImage(source: ImageSource.gallery);
//
//     if (pickedFile != null) {
//       setState(() {
//         _image = File(pickedFile.path);
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         title: const Text("Back"),
//       ),
//       body: SafeArea(
//         child: Form(
//           key: _formKey,
//           child: SingleChildScrollView(
//             child: Column(
//               children: [
//                 const Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: Align(
//                     alignment: Alignment.center,
//                     child: Text(
//                       "ADD TENDER",
//                       style: TextStyle(
//                         fontSize: 25,
//                         fontWeight: FontWeight.bold,
//                         color: Colors.brown,
//                       ),
//                     ),
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: nameController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Name",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter a name';
//                       }
//                       return null;
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: descriptionController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Description",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter a description';
//                       }
//                       return null;
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: dateController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Select last date",
//                       suffixIcon: Icon(Icons.calendar_today),
//                     ),
//                     readOnly: true, // Make the field read-only so users can only select a date from the picker
//                     onTap: () async {
//                       DateTime? pickedDate = await showDatePicker(
//                         context: context,
//                         initialDate: DateTime.now(),
//                         firstDate: DateTime(1900),
//                         lastDate: DateTime(2101),
//                       );
//
//                       if (pickedDate != null) {
//                         setState(() {
//                           dateController.text = "${pickedDate.toLocal()}".split(' ')[0]; // Format as "YYYY-MM-DD"
//                         });
//                       }
//                     },
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please select a date';
//                       }
//                       return null;
//                     },
//                   ),
//                 ),
//                 Padding(
//                   padding: EdgeInsets.all(8.0),
//                   child: TextFormField(
//                     controller: priceController,
//                     decoration: InputDecoration(
//                       fillColor: Colors.white,
//                       border: OutlineInputBorder(),
//                       hintText: "Price",
//                     ),
//                     validator: (value) {
//                       if (value!.isEmpty) {
//                         return 'Please enter a price';
//                       }
//                       if (double.tryParse(value) == null) {
//                         return 'Please enter a valid price';
//                       }
//                       return null;
//                     },
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 // Image picker button
//                 ElevatedButton.icon(
//                   onPressed: _pickImage,
//                   icon: const Icon(Icons.camera_alt),
//                   label: Text(_image == null ? 'Pick an Image' : 'Image Selected'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.lightGreen,
//                   ),
//                 ),
//                 const SizedBox(height: 20),
//                 ElevatedButton(
//                   onPressed: () {
//                     if (_formKey.currentState!.validate() && _image != null) {
//                       // Call your backend code or perform further actions here
//                       Fluttertoast.showToast(msg: 'Tender Added Successfully');
//                       nameController.clear();
//                       descriptionController.clear();
//                       dateController.clear();
//                       priceController.clear();
//                       setState(() {
//                         _image = null;
//                       });
//                     } else {
//                       Fluttertoast.showToast(msg: 'Please fill in all fields and select an image');
//                     }
//                   },
//                   child: const Text('Add tender'),
//                   style: ElevatedButton.styleFrom(
//                     backgroundColor: Colors.lightGreen,
//                   ),
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }





import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';


import 'dart:io';

import 'Home.dart';
import 'managetender.dart';



class AddDocument extends StatefulWidget {
  const AddDocument({super.key, required this.title});

  final String title;

  @override
  State<AddDocument> createState() => _AddDocumentState();
}

class _AddDocumentState extends State<AddDocument> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController descriptionController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController priceController = TextEditingController();
  File? _image;
  final _formKey = GlobalKey<FormState>();



  // Method to pick an image from the gallery or camera
  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text("Back"),
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            child: Column(
              children: [
                const Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      "ADD TENDER",
                      style: TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.bold,
                        color: Colors.brown,
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: nameController,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      hintText: "Name",
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter a name';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: descriptionController,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      hintText: "Description",
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter a description';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: dateController,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      hintText: "Select last date",
                      suffixIcon: Icon(Icons.calendar_today),
                    ),
                    readOnly: true, // Make the field read-only so users can only select a date from the picker
                    onTap: () async {
                      DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1900),
                        lastDate: DateTime(2101),
                      );

                      if (pickedDate != null) {
                        setState(() {
                          dateController.text = "${pickedDate.toLocal()}".split(' ')[0]; // Format as "YYYY-MM-DD"
                        });
                      }
                    },
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please select a date';
                      }
                      return null;
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.all(8.0),
                  child: TextFormField(
                    controller: priceController,
                    decoration: InputDecoration(
                      fillColor: Colors.white,
                      border: OutlineInputBorder(),
                      hintText: "Price",
                    ),
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return 'Please enter a price';
                      }
                      if (double.tryParse(value) == null || double.parse(value) <= 0) {
                        return 'Please enter a valid price';
                      }
                      return null;
                    },
                  ),
                ),
                const SizedBox(height: 20),
                // Image picker button
                ElevatedButton.icon(
                  onPressed: _pickImage,
                  icon: const Icon(Icons.camera_alt),
                  label: Text(_image == null ? 'Pick an Image' : 'Image Selected'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal[300],
                  ),
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate() && _image != null) {
                      _addDocument();
                    } else {
                      Fluttertoast.showToast(msg: 'Please fill in all fields and select an image');
                    }
                  },
                  child: const Text('Add tender'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.lightGreen,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }




  void _addDocument() async {
    String details = descriptionController.text.trim();
    String name = nameController.text.trim();

    SharedPreferences sh = await SharedPreferences.getInstance();
    String? url = sh.getString('url');
    String? lid = sh.getString('lid');

    if (url == null || lid == null) {
      Fluttertoast.showToast(msg: 'Invalid configuration. Please try again.');
      return;
    }

    final Uri apiUrl = Uri.parse(url + "contractrotender_add");

    try {
      // Prepare the request to send the data and the file
      var request = http.MultipartRequest('POST', apiUrl)
        ..fields['name'] = name
        ..fields['desc'] = details
        ..fields['lastdate'] = dateController.text // Using dateController text
        ..fields['minmax'] = priceController.text // Using priceController text
        ..fields['lid'] = lid;

      // Attach the image file if it's selected
      if (_image != null) {
        var file = await http.MultipartFile.fromPath('files', _image!.path);
        request.files.add(file);
      }

      var response = await request.send();

      if (response.statusCode == 200) {
        final responseData = await response.stream.bytesToString();
        var data = jsonDecode(responseData);

        if (data['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Tender Added Successfully');
          nameController.clear();
          descriptionController.clear();
          dateController.clear();
          priceController.clear();
          setState(() {
            _image = null;
          });
          // Navigate to Home page and remove previous screens from stack
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => ManageTender()), // Navigate to Home
                (route) => false, // Remove all previous routes
          );
        } else {
          Fluttertoast.showToast(msg: 'Error: tender not added.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Server Error: ${response.statusCode}');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Network Error: ${e.toString()}');
    }
  }


}


