import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:tender_management/userpayment.dart';

class tenderreq extends StatefulWidget {
  @override
  _TenderManageState createState() => _TenderManageState();
}

class _TenderManageState extends State<tenderreq> {
  List<Map<String, dynamic>> tenders = [];

  @override
  void initState() {
    super.initState();
    loadTenders();
  }

  Future<void> loadTenders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? lid = prefs.getString("lid");
      String? baseUrl = prefs.getString("url");

      if (lid == null || baseUrl == null) {
        throw Exception("Missing credentials or URL");
      }

      final response = await http.post(
        Uri.parse(baseUrl + "viewtender_request"),
        body: {
          'lid': lid,
          'tid': prefs.getString("tid").toString(),
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'ok') {
          setState(() {
            tenders = List<Map<String, dynamic>>.from(data['data']);
          });
        } else {
          print("Error: ${data['message']}");
        }
      } else {
        print("HTTP Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  Future<void> updateTenderStatus(String tenderId, String action) async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? lid = prefs.getString("lid");
      String? baseUrl = prefs.getString("url");

      if (lid == null || baseUrl == null) {
        throw Exception("Missing credentials or URL");
      }

      final response = await http.post(
        Uri.parse(baseUrl + "update_tender_status"),
        body: {
          'lid': lid.toString(),
          'tender_reqid': tenderId.toString(),
          'tid': prefs.getString("tid").toString(),
          'action': action.toString(),
        },
      );

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'ok') {
          loadTenders();
        } else {
          print("Error: ${data['message']}");
        }
      } else {
        print("HTTP Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tender Requests"),
      ),
      body: tenders.isEmpty
          ? Center(child: Text('No Tenders Found'))
          : ListView.builder(
        itemCount: tenders.length,
        itemBuilder: (context, index) {
          final tender = tenders[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text("Company: ${tender['COMPANY']}"),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("ID: ${tender['id'].toString()}"),
                  Text("Date: ${tender['date'].toString()}"),
                  Text("Amount: ${tender['amount'].toString()}"),
                  Text("Status: ${tender['status'].toString()}"),
                ],
              ),
              trailing: tender['status'] == 'accept'
                  ? Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Accepted',
                    style: TextStyle(
                      color: Colors.green,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.payment, color: Colors.blue),
                    onPressed: () async {
                      final pref = await SharedPreferences.getInstance();
                      pref.setString("trid", tender['id'].toString());
                      pref.setString("amd", pref.getString("amount").toString());

                      Navigator.pushAndRemoveUntil(
                        context,
                        MaterialPageRoute(builder: (context) => UserPaymentScreen()), // Navigate to Home
                            (route) => false, // Remove all previous routes
                      );
                      // Add payment functionality here
                      //print(
                      //    'Payment icon clicked for tender ID: ${tender['id']}');
                    },
                  ),
                ],
              )
                  : tender['status'] == 'reject'
                  ? Text(
                'Rejected',
                style: TextStyle(
                  color: Colors.red,
                  fontWeight: FontWeight.bold,
                ),
              )
                  : Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.check_circle,
                        color: Colors.green),
                    onPressed: () {
                      updateTenderStatus(
                          tender['id'].toString(), 'accept');
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.cancel, color: Colors.red),
                    onPressed: () {
                      updateTenderStatus(
                          tender['id'].toString(), 'reject');
                    },
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
