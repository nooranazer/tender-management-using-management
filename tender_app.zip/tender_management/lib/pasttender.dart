import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class pasttender extends StatefulWidget {
  @override
  _TenderManageState createState() => _TenderManageState();
}

class _TenderManageState extends State<pasttender> {
  List<Map<String, dynamic>> tenders = [];

  @override
  void initState() {
    super.initState();
    loadTenders();
  }

  Future<void> loadTenders() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      String? lid = prefs.getString("lid");
      String? baseUrl = prefs.getString("url");

      if (lid == null || baseUrl == null) {
        throw Exception("Missing credentials or URL");
      }

      final response = await http.post(
        Uri.parse(baseUrl + "contractorpast_tender"), // Concatenate the endpoint directly
        body: {'lid': lid},
      );


      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['status'] == 'ok') {
          setState(() {
            tenders = List<Map<String, dynamic>>.from(data['data']);
          });
        } else {
          print("Error: ${data['message']}");
        }
      } else {
        print("HTTP Error: ${response.statusCode}");
      }
    } catch (e) {
      print("Error: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Past Tenders"),
      ),
      body: tenders.isEmpty
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: tenders.length,
        itemBuilder: (context, index) {
          final tender = tenders[index];
          return Card(
            margin: EdgeInsets.all(8.0),
            child: ListTile(
              title: Text("Name: ${tender['name']}"),
              subtitle: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Description: ${tender['description']}"),
                  Text("Last Date: ${tender['lastdate']}"),
                  Text("Price: ${tender['min_max']}"),
                  if (tender['document'].isNotEmpty)
                    Text("Document: ${tender['document']}"),
                  Text("Status: ${tender['status']}"),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
