// import 'dart:convert';
//
//
// import 'package:flutter/material.dart';
//
//
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'package:tender_management/registration.dart';
//
// import 'home.dart';
// class login extends StatefulWidget {
//   const login({super.key});
//
//   @override
//   State<login> createState() => _loginState();
// }
//
// class _loginState extends State<login> {
//
//
//   final TextEditingController usernameController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Login"),
//       ),
//       body: SafeArea(
//         child: Center(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: TextFormField(
//                   controller: usernameController,
//                   decoration: const InputDecoration(
//                     filled: true,
//                     fillColor: Colors.white,
//                     border: OutlineInputBorder(),
//                     hintText: "Username",
//                   ),
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: TextFormField(
//                   controller: passwordController,
//                   decoration: const InputDecoration(
//                     filled: true,
//                     fillColor: Colors.white,
//                     border: OutlineInputBorder(),
//                     hintText: "Password",
//                   ),
//                 ),
//               ),
//               Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     Padding(
//                       padding: EdgeInsets.all(16.0),
//                       child: ElevatedButton(
//                         onPressed: () {
//                            Navigator.push(context,
//                               MaterialPageRoute(builder: (context) => Registration()));
//                         },
//                         child: Text("Registration"),
//                       ),
//                     ),
//                     Padding(
//                       padding: const EdgeInsets.all(16.0),
//                       child: ElevatedButton(
//                         onPressed: ()async {
//                           final sh = await SharedPreferences.getInstance();
//                           String Uname=usernameController.text.toString();
//                           String Passwd=passwordController.text.toString();
//                           String url = sh.getString("url").toString();
//                           print("okkkkkkkkkkkkkkkkk");
//                           var data = await http.post(
//                               Uri.parse(url+"and_logincode"),
//                               body: {'username':Uname,
//                                 "password":Passwd,
//                               });
//                           var jasondata = json.decode(data.body);
//                           String status=jasondata['task'].toString();
//                           String type=jasondata['type'].toString();
//                           if(status=="valid") {
//                             if (type == 'contractor') {
//                               String lid = jasondata['lid'].toString();
//                               sh.setString("lid", lid);
//                               Navigator.push(context,
//                                   MaterialPageRoute(
//                                       builder: (context) => home()));
//                             }
//                             // else if (type == 'contractor') {
//                             //   String lid = jasondata['lid'].toString();
//                             //   sh.setString("lid", lid);
//                             //   Navigator.push(context,
//                             //       MaterialPageRoute(
//                             //           builder: (context) => home()));
//                             // }
//                             else{
//                               print("error");
//
//                             }
//                           }
//                           else{
//                             print("error");
//
//                           }
//
//                         },
//                         child: const Text("Login"),
//                       ),
//                     )
//                   ]),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



//original

// import 'dart:convert';
// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:http/http.dart' as http;
// import 'package:tender_management/UserHome.dart';
// import 'package:tender_management/registration.dart';
// import 'home.dart';
//
// class login extends StatefulWidget {
//   const login({super.key});
//
//   @override
//   State<login> createState() => _loginState();
// }
//
// class _loginState extends State<login> {
//   final TextEditingController usernameController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       backgroundColor: Colors.grey[100],
//       appBar: AppBar(
//         title: const Text(
//           "Login",
//           style: TextStyle(
//             fontWeight: FontWeight.bold,
//             letterSpacing: 1.5,
//           ),
//         ),
//         backgroundColor: Colors.cyanAccent[700],
//         elevation: 0,
//       ),
//       body: SafeArea(
//         child: Center(
//           child: Padding(
//             padding: const EdgeInsets.symmetric(horizontal: 20.0),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 const Text(
//                   "Welcome Back!",
//                   style: TextStyle(
//                     fontSize: 24.0,
//                     fontWeight: FontWeight.bold,
//                     color: Colors.black87,
//                   ),
//                 ),
//                 const SizedBox(height: 10),
//                 const Text(
//                   "Login to continue",
//                   style: TextStyle(
//                     fontSize: 16.0,
//                     color: Colors.black54,
//                   ),
//                 ),
//                 const SizedBox(height: 30),
//                 TextFormField(
//                   controller: usernameController,
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(10.0),
//                     ),
//                     filled: true,
//                     fillColor: Colors.white,
//                     hintText: "Username",
//                     prefixIcon: const Icon(Icons.person),
//                   ),
//                   style: const TextStyle(fontSize: 16.0),
//                 ),
//                 const SizedBox(height: 20),
//                 TextFormField(
//                   controller: passwordController,
//                   obscureText: true,
//                   decoration: InputDecoration(
//                     border: OutlineInputBorder(
//                       borderRadius: BorderRadius.circular(10.0),
//                     ),
//                     filled: true,
//                     fillColor: Colors.white,
//                     hintText: "Password",
//                     prefixIcon: const Icon(Icons.lock),
//                   ),
//                   style: const TextStyle(fontSize: 16.0),
//                 ),
//                 const SizedBox(height: 30),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
//                   children: [
//                     ElevatedButton(
//                       onPressed: () {
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => Registration()),
//                         );
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.cyanAccent[700],
//                         padding: const EdgeInsets.symmetric(
//                             horizontal: 20.0, vertical: 12.0),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10.0),
//                         ),
//                       ),
//                       child: const Text(
//                         "Register",
//                         style: TextStyle(
//                           fontSize: 16.0,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                     ElevatedButton(
//                       onPressed: () async {
//                         final sh = await SharedPreferences.getInstance();
//                         String Uname = usernameController.text.toString();
//                         String Passwd = passwordController.text.toString();
//                         String url = sh.getString("url").toString();
//                         print("okkkkkkkkkkkkkkkkk");
//                         var data = await http.post(
//                           Uri.parse(url + "and_logincode"),
//                           body: {'username': Uname, "password": Passwd},
//                         );
//                         var jasondata = json.decode(data.body);
//                         String status = jasondata['task'].toString();
//                         String type = jasondata['type'].toString();
//                         if (status == "valid") {
//                           if (type == 'contractor') {
//                             String lid = jasondata['lid'].toString();
//                             sh.setString("lid", lid);
//                             Navigator.push(
//                               context,
//                               MaterialPageRoute(builder: (context) => UserHomePage()),
//                             );
//                           } else {
//                             print("error");
//                           }
//                         } else {
//                           print("error");
//                         }
//                       },
//                       style: ElevatedButton.styleFrom(
//                         backgroundColor: Colors.cyanAccent[700],
//                         padding: const EdgeInsets.symmetric(
//                             horizontal: 20.0, vertical: 12.0),
//                         shape: RoundedRectangleBorder(
//                           borderRadius: BorderRadius.circular(10.0),
//                         ),
//                       ),
//                       child: const Text(
//                         "Login",
//                         style: TextStyle(
//                           fontSize: 16.0,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ),
//       ),
//     );
//   }
// }



import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:tender_management/UserHome.dart';
import 'package:tender_management/registration.dart';
import 'home.dart';

class login extends StatefulWidget {
  const login({super.key});

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text(
          "Login",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            letterSpacing: 1.5,
          ),
        ),
        backgroundColor: Colors.cyanAccent[700],
        elevation: 0,
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Text(
                    "Welcome Back!",
                    style: TextStyle(
                      fontSize: 24.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Text(
                    "Login to continue",
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Colors.black54,
                    ),
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: usernameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "Username",
                      prefixIcon: const Icon(Icons.person),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return "Username cannot be empty";
                      }
                      return null;
                    },
                    style: const TextStyle(fontSize: 16.0),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    controller: passwordController,
                    obscureText: true,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                      hintText: "Password",
                      prefixIcon: const Icon(Icons.lock),
                    ),
                    validator: (value) {
                      if (value == null || value.trim().isEmpty) {
                        return "Password cannot be empty";
                      } else if (value.length < 8) {
                        return "Password must be at least 8 characters";
                      }
                      return null;
                    },
                    style: const TextStyle(fontSize: 16.0),
                  ),
                  const SizedBox(height: 30),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => Registration()),
                          );
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyanAccent[700],
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20.0, vertical: 12.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        child: const Text(
                          "Register",
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      ElevatedButton(
                        onPressed: () async {
                          if (_formKey.currentState!.validate()) {
                            final sh = await SharedPreferences.getInstance();
                            String Uname = usernameController.text.toString();
                            String Passwd = passwordController.text.toString();
                            String url = sh.getString("url").toString();
                            print("okkkkkkkkkkkkkkkkk");
                            var data = await http.post(
                              Uri.parse(url + "and_logincode"),
                              body: {'username': Uname, "password": Passwd},
                            );
                            var jasondata = json.decode(data.body);
                            String status = jasondata['task'].toString();
                            String type = jasondata['type'].toString();
                            if (status == "valid") {
                              if (type == 'contractor') {
                                String lid = jasondata['lid'].toString();
                                sh.setString("lid", lid);
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) => UserHomePage()),
                                );
                              } else {
                                print("error");
                              }
                            } else {
                              print("error");
                            }
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.cyanAccent[700],
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20.0, vertical: 12.0),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0),
                          ),
                        ),
                        child: const Text(
                          "Login",
                          style: TextStyle(
                            fontSize: 16.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
