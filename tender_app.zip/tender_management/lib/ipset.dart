// import 'package:flutter/material.dart';
// import 'package:shared_preferences/shared_preferences.dart';
//
// import 'login.dart';
//
//
//
//
//
//
// class ipset extends StatefulWidget {
//   const ipset({super.key});
//
//   @override
//   State<ipset> createState() => _ipsetstate();
// }
//
// class _ipsetstate extends State<ipset> {
//   final TextEditingController ipController = TextEditingController();
//   @override
//   Widget build(BuildContext context) {
//
//     return Scaffold(
//       backgroundColor: Colors.white,
//       appBar: AppBar(
//         title: const Text("TENDER"),
//       ),
//       body: SafeArea(
//         child: Center(
//           child: Column(
//             mainAxisAlignment: MainAxisAlignment.center,
//             crossAxisAlignment: CrossAxisAlignment.center,
//             children: [
//               Padding(
//                 padding: const EdgeInsets.all(2),
//                 child: TextField(
//
//                   controller: ipController,
//                   decoration: const InputDecoration(
//                       border: OutlineInputBorder(),
//                       labelText: "IP Address",
//                       hintText: "Enter a valid ip address"),
//
//
//                 ),
//               ),
//               Padding(
//                 padding: const EdgeInsets.all(16.0),
//                 child: ElevatedButton(
//                   onPressed: () async{
//
//                     String ip=ipController.text.toString();
//                     final sh = await SharedPreferences.getInstance();
//                     sh.setString("url", "http://"+ip+":8000/");
//                     sh.setString("imgurl", "http://"+ip+":8000");
//                      Navigator.push(context, MaterialPageRoute(builder: (context) => login()));
//                   },
//                   child: const Icon(Icons.key),
//
//                   style: ButtonStyle(
//                     backgroundColor: MaterialStateProperty.all<Color>(
//                       Colors.amber, // Use a proper color value (e.g., Hex or RGB)
//                     ),
//                   ),
//                 ),
//               )
//
//             ],
//           ),
//         ),
//       ),
//     );
//   }
// }



import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'login.dart';

class ipset extends StatefulWidget {
  const ipset({super.key});

  @override
  State<ipset> createState() => _ipsetstate();
}

class _ipsetstate extends State<ipset> {
  final TextEditingController ipController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text(
          "TENDER",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            letterSpacing: 2.0,
          ),
        ),
        backgroundColor: Colors.amber[700],
        elevation: 0,
      ),
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                const Text(
                  "Set IP Address",
                  style: TextStyle(
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
                const SizedBox(height: 20),
                TextField(
                  controller: ipController,
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                    labelText: "IP Address",
                    hintText: "Enter a valid IP address",
                    prefixIcon: const Icon(Icons.language),
                    filled: true,
                    fillColor: Colors.white,
                  ),
                  style: const TextStyle(fontSize: 16.0),
                ),
                const SizedBox(height: 20),
                ElevatedButton.icon(
                  onPressed: () async {
                    String ip = ipController.text.toString();
                    final sh = await SharedPreferences.getInstance();
                    sh.setString("url", "http://" + ip + ":8000/");
                    sh.setString("imgurl", "http://" + ip + ":8000");
                    Navigator.push(
                        context, MaterialPageRoute(builder: (context) => login()));
                  },
                  icon: const Icon(Icons.key),
                  label: const Text(
                    "Save & Continue",
                    style: TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.amber[700],
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20.0, vertical: 12.0),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
