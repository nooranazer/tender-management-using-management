import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:tender_management/managetender.dart';

void main() {
  runApp(UserPaymentScreen());
}

class UserPaymentScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Razorpay Payment',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Arial',
        scaffoldBackgroundColor: Colors.white,
        primarySwatch: Colors.blue,
      ),
      home: UserPaymentScreenPage(),
    );
  }
}

class UserPaymentScreenPage extends StatefulWidget {
  @override
  _UserPaymentScreenPageState createState() => _UserPaymentScreenPageState();
}

class _UserPaymentScreenPageState extends State<UserPaymentScreenPage> {
  late Razorpay _razorpay;
  final TextEditingController _amountController = TextEditingController();
  String amount_='';
  @override
  void initState() {
    super.initState();
    h();
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
  }
  Future<void> h() async {
    SharedPreferences sh = await SharedPreferences.getInstance();
    setState(() {
      amount_ = sh.getString("amd").toString().split(".")[0];
    });
  }
  @override
  void dispose() {
    _razorpay.clear();
    super.dispose();
  }

  Future<void> _handlePaymentSuccess(PaymentSuccessResponse response) async {
    // ScaffoldMessenger.of(context).showSnackBar(
    //   SnackBar(content: Text("Payment successful: ${response.paymentId}")),
    // );


    final sh = await SharedPreferences.getInstance();
    String amount = amount_.toString();
    // String Passwd=passwordController.text.toString();
    String url = sh.getString("url").toString();
    String reqid = sh.getString("reqid").toString();
    String lid = sh.getString("lid").toString();
    String statuss = "payment";
    print("okkkkkkkkkkkkkkkkk");
    var data = await http.post(
        Uri.parse(url + "updaterequeststatus"),
        body: {
          'tenderreq_id': sh.getString("trid").toString(),
          'lid': sh.getString("lid").toString(),
        });
    var jasondata = json.decode(data.body);
    String status = jasondata['status'].toString();
    if (status == "ok") {
      Navigator.push(context,
          MaterialPageRoute(builder: (context) => ManageTender()));
    }
    else {
      print("error");
    }
    // Handle success scenario here

  }

  void _handlePaymentError(PaymentFailureResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Payment failed: ${response.message}")),
    );
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("External wallet selected: ${response.walletName}")),
    );
  }

  Future<void> _makePayment() async {
    if (_amountController.text.isEmpty) {
      return;
    }
    // Mocking the payment server-side call.
    _openCheckout();
  }

  void _openCheckout() {
    var options = {
      'key': 'rzp_test_edrzdb8Gbx5U5M',
      'amount': int.parse(_amountController.text) * 100,
      'name': 'Flutter Razorpay Demo',
      'description': 'Test Payment',
      'prefill': {'contact': '8136841963', 'email': 'akhilaregional@gmail.com'},
      'external': {'wallets': ['paytm']},
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      print('Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error opening Razorpay checkout: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    _amountController.text=amount_.toString();
    return Scaffold(
      appBar: AppBar(
        title: Text('Payment'),
        leading: IconButton(onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => ManageTender()),
          );
        }, icon: const Icon(Icons.arrow_back),),
        backgroundColor: Colors.blueAccent,
        centerTitle: true,
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              'Enter the Amount to Pay',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: Colors.black87),
            ),
            SizedBox(height: 20),
            TextField(
              controller: _amountController,
              keyboardType: TextInputType.number,
              style: TextStyle(fontSize: 18),
              decoration: InputDecoration(
                hintText: 'Enter Amount',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.blueAccent, width: 2),
                  borderRadius: BorderRadius.circular(10),
                ),
                prefixIcon: Icon(Icons.currency_rupee, color: Colors.blueAccent),
              ),
              enabled: false,
            ),
            SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _amountController.text.isEmpty ? null : _makePayment,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blueAccent,
                  padding: EdgeInsets.symmetric(vertical: 15),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
                child: Text(
                  'Pay Now',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
