
import 'package:flutter/material.dart';
import 'package:tender_management/Home.dart';
import 'package:tender_management/complaint.dart';
import 'package:tender_management/managetender.dart';
import 'package:tender_management/pasttender.dart';
import 'package:tender_management/profile.dart';
import 'package:tender_management/tenderreq.dart';
// import 'package:ksrtc/payment.dart';
// import 'package:ksrtc/qr.dart';
// import 'package:ksrtc/send%20feedback.dart';
// import 'package:ksrtc/view%20bus.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import 'booking.dart';
// import 'home.dart';
import 'login.dart';
import 'ongoingtender.dart';
class Drawerclass extends StatelessWidget {
  const Drawerclass({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          const DrawerHeader(
            decoration: BoxDecoration(
              color: Colors.red,
            ),
            child: Text(
              "My App",
              style: TextStyle(color: Colors.black, fontSize: 24),
            ),
          ),
          ListTile(
            leading: IconButton(
              onPressed: () {
                // Handle icon button press
              },
              icon: const Icon(Icons.home),
            ),
            title: const Text("Home"),
            onTap: () {
               Navigator.push(context, MaterialPageRoute(builder: (context) => const home()));
            },

          ),
          // ListTile(
          //   leading:
          //   IconButton(onPressed: () {}, icon: const Icon(Icons.account_circle)),
          //   title: const Text("PROFILE"),
          //   onTap: () {
          //      Navigator.push(context, MaterialPageRoute(builder: (context) => ProfilePage()));
          //   },
          // ),
          // ListTile(
          //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.work)),
          //   title: const Text("TENDERS"),
          //   onTap: () {
          //     Navigator.push(context, MaterialPageRoute(builder: (context) => ManageTender()));
          //
          //   },
          // ),
          //
          // ListTile(
          //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.work_history_rounded)),
          //   title: const Text("PAST TENDER"),
          //   onTap: () {
          //     Navigator.push(context, MaterialPageRoute(builder: (context) => pasttender()));
          //
          //   },
          // ),
          //
          // ListTile(
          //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.event )),
          //   title: const Text("ONGOING TENDER"),
          //   onTap: () {
          //     Navigator.push(context, MaterialPageRoute(builder: (context) => ongoingtender()));
          //
          //   },
          // )
          // ,
          // // ListTile(
          // //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.feedback)),
          // //   title: const Text("TENDER REQUEST"),
          // //   onTap: () {
          // //     Navigator.push(context, MaterialPageRoute(builder: (context) =>tenderreq()));
          // //
          // //     },
          // // ),
          // ListTile(
          //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.feedback_outlined)),
          //   title: const Text("COMPLAINT"),
          //   onTap: () {
          //     Navigator.push(context, MaterialPageRoute(builder: (context) => AppComplaint()));
          //
          //   },
          // ),
          // // ListTile(
          // //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.payment)),
          // //   title: const Text("PAYMENT"),
          // //   // onTap: () {
          // //   //   // Navigator.push(context, MaterialPageRoute(builder: (context) => YourScreen()));
          // //   //
          // //   // },
          // //
          // //
          // //
          // // ),
          // //
          // ListTile(
          //   leading: IconButton(onPressed: () {}, icon: const Icon(Icons.logout)),
          //   title: const Text("Logout"),
          //   onTap: () {
          //     Navigator.push(
          //       context,
          //       MaterialPageRoute(builder: (context) => const login()),
          //     );
          //   },
          // ),
        ],
      ),
    );
  }
}