//
//
//
//
//
//
//
//
// import 'dart:io';
// import 'package:flutter/material.dart';
// import 'package:image_picker/image_picker.dart';
// import 'package:permission_handler/permission_handler.dart';
// import 'package:http/http.dart' as http;
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:tender_management/managetender.dart';
// import 'dart:convert';
//
// import 'Home.dart';
//
// class EditTender extends StatefulWidget {
//   const EditTender({Key? key}) : super(key: key);
//
//   @override
//   State<EditTender> createState() => _EditTenderState();
// }
//
// class _EditTenderState extends State<EditTender> {
//   final _formKey = GlobalKey<FormState>();
//   final  nameController = TextEditingController();
//   final  descriptionController = TextEditingController();
//   final  lastDateController = TextEditingController();
//   final  priceController = TextEditingController();
//
//   String? _oldImageUrl; // URL of the old image
//   File? _selectedImage; // File object for the newly selected image
//
//   Future<void> _pickImage() async {
//     final picker = ImagePicker();
//     final pickedFile = await picker.pickImage(source: ImageSource.gallery);
//
//     if (pickedFile != null) {
//       setState(() {
//         _selectedImage = File(pickedFile.path);
//       });
//     }
//   }
//
//   @override
//   void initState() {
//     super.initState();
//     _fetchTenderDetails();
//   }
//
//   // Fetch existing tender details from the server
//   void _fetchTenderDetails() async {
//     SharedPreferences sh = await SharedPreferences.getInstance();
//     String url = sh.getString('url') ?? '';
//     String tid = sh.getString('tid') ?? '';
//
//     final Uri apiUrl = Uri.parse(url + 'contractortenderedit_view');
//     print(apiUrl);
//     try {
//       final response = await http.post(apiUrl, body: {'tid': tid});
//       if (response.statusCode == 200) {
//         final data = jsonDecode(response.body);
//         print(data);
//         if (data['status'] == 'ok' && data['data'] != null && data['data'].isNotEmpty) {
//           final tenderData = data['data'][0]; // Access the first item in the data array
//           setState(() {
//             nameController.text = tenderData['name'] ?? '';
//             descriptionController.text = tenderData['description'] ?? '';
//             lastDateController.text = tenderData['lastdate'] ?? '';
//             priceController.text = tenderData['min_max'].toString() ?? '';
//             _oldImageUrl = tenderData['document'] ?? '';
//           });
//         }
//         else {
//           Fluttertoast.showToast(msg: 'Failed to load data');
//         }
//       } else {
//         Fluttertoast.showToast(msg: 'Network Error');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: e.toString());
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text('Edit Tender'),
//         backgroundColor: Colors.teal,
//       ),
//       body: SingleChildScrollView(
//         padding: const EdgeInsets.all(16.0),
//         child: Form(
//           key: _formKey,
//           child: Column(
//             children: [
//               _buildTextField("Name", nameController, "Please enter the name"),
//               _buildTextField("Description", descriptionController, "Please enter a description"),
//               _buildTextField("Last Date", lastDateController, "Please enter the last date"),
//               _buildTextField("Price", priceController, "Please enter the price"),
//               const SizedBox(height: 20),
//               _buildImagePicker(),
//               const SizedBox(height: 20),
//               ElevatedButton(
//                 onPressed: _updateTender,
//                 child: const Text("Update Tender"),
//               ),
//             ],
//           ),
//         ),
//       ),
//     );
//   }
//
//   // Generic text field builder
//   Padding _buildTextField(String label, TextEditingController controller, String validationMessage) {
//     return Padding(
//       padding: const EdgeInsets.symmetric(vertical: 8.0),
//       child: TextFormField(
//         controller: controller,
//         decoration: InputDecoration(
//           border: const OutlineInputBorder(),
//           labelText: label,
//         ),
//         validator: (value) {
//           if (value == null || value.isEmpty) {
//             return validationMessage;
//           }
//           return null;
//         },
//       ),
//     );
//   }
//
//   // Image picker widget
//   Widget _buildImagePicker() {
//     return Column(
//       children: [
//         GestureDetector(
//           onTap: _checkPermissionAndChooseImage,
//           child: Container(
//             height: 200,
//             width: 200,
//             decoration: BoxDecoration(
//               border: Border.all(color: Colors.grey),
//               borderRadius: BorderRadius.circular(8.0),
//             ),
//             child: _selectedImage != null
//                 ? Image.file(_selectedImage!, fit: BoxFit.cover)
//                 : _oldImageUrl != null && _oldImageUrl!.isNotEmpty
//                 ? Image.network(_oldImageUrl!, fit: BoxFit.cover)
//                 : const Center(
//               child: Text("Select Image", style: TextStyle(color: Colors.grey)),
//             ),
//           ),
//         ),
//         const SizedBox(height: 8),
//         const SizedBox(height: 20),
//         // Image picker button
//         ElevatedButton.icon(
//           onPressed: _pickImage,
//           icon: const Icon(Icons.camera_alt),
//           label: Text(_selectedImage == null ? 'Pick an Image' : 'Image Selected'),
//           style: ElevatedButton.styleFrom(
//             backgroundColor: Colors.lightGreen,
//           ),
//         ),
//         const Text("Tap to select an image"),
//       ],
//     );
//   }
//
//   // Method to choose and upload an image
//   Future<void> _chooseAndUploadImage() async {
//     final picker = ImagePicker();
//     final pickedImage = await picker.pickImage(source: ImageSource.gallery);
//     if (pickedImage != null) {
//       setState(() {
//         _selectedImage = File(pickedImage.path);
//       });
//     }
//   }
//
//   // Check permissions for image selection
//   Future<void> _checkPermissionAndChooseImage() async {
//     final PermissionStatus status = await Permission.photos.request();
//     if (status.isGranted) {
//       _chooseAndUploadImage();
//     } else {
//       _showPermissionDeniedDialog();
//     }
//   }
//
//   // Show permission denied dialog
//   void _showPermissionDeniedDialog() {
//     showDialog(
//       context: context,
//       builder: (BuildContext context) => AlertDialog(
//         title: const Text('Permission Denied'),
//         content: const Text('Please enable photo permissions in your settings.'),
//         actions: [
//           TextButton(
//             onPressed: () => Navigator.pop(context),
//             child: const Text('OK'),
//           ),
//         ],
//       ),
//     );
//   }
//
//   // Method to update tender details
//   // void _updateTender() async {
//   //   if (_formKey.currentState!.validate()) {
//   //     SharedPreferences sh = await SharedPreferences.getInstance();
//   //     String url = sh.getString('url') ?? '';
//   //     String tid = sh.getString('tid') ?? '';
//   //     print(tid);
//   //     print('===============================');
//   //     print(url + 'contractortende_edit');
//   //
//   //     final request = http.MultipartRequest('POST', Uri.parse(url + 'contractortende_edit'))
//   //       ..fields['tid'] = tid
//   //       ..fields['name'] = nameController.text
//   //       ..fields['desc'] = descriptionController.text
//   //       ..fields['last'] = lastDateController.text
//   //       ..fields['price'] = priceController.text;
//   //
//   //     if (_selectedImage != null) {
//   //       request.files.add(await http.MultipartFile.fromPath('document', _selectedImage!.path));
//   //     }
//   //
//   //     try {
//   //       final response = await request.send();
//   //       final responseData = await http.Response.fromStream(response);
//   //       final jsonResponse = json.decode(responseData.body);
//   //
//   //       if (jsonResponse['status'] == 'ok') {
//   //         Fluttertoast.showToast(msg: 'Tender updated successfully');
//   //         Navigator.pop(context);
//   //       } else {
//   //         Fluttertoast.showToast(msg: 'Failed to update tender');
//   //       }
//   //     } catch (e) {
//   //       Fluttertoast.showToast(msg: 'Error: $e');
//   //     }
//   //   }
//   // }
//
//
//
//   void _updateTender() async {
//     String details = descriptionController.text.trim();
//     String name = nameController.text.trim();
//
//     SharedPreferences sh = await SharedPreferences.getInstance();
//     String? url = sh.getString('url');
//     String? lid = sh.getString('tid');
//
//     if (url == null || lid == null) {
//       Fluttertoast.showToast(msg: 'Invalid configuration. Please try again.');
//       return;
//     }
//
//     final Uri apiUrl = Uri.parse(url + "contractortende_edit");
//
//     try {
//       // Prepare the request to send the data and the file
//       var request = http.MultipartRequest('POST', apiUrl)
//         ..fields['name'] = name
//         ..fields['desc'] = details
//         ..fields['price'] = priceController.text // Using priceController text
//       ..fields['last'] = lastDateController.text
//
//         ..fields['tid'] = lid;
//
//       // Attach the image file if it's selected
//       if (_selectedImage != null) {
//         var file = await http.MultipartFile.fromPath('document', _selectedImage!.path);
//         request.files.add(file);
//       }
//
//       var response = await request.send();
//
//       if (response.statusCode == 200) {
//         final responseData = await response.stream.bytesToString();
//         var data = jsonDecode(responseData);
//         print(data);
//         print('==================');
//
//         if (data['status'] == 'ok') {
//           Fluttertoast.showToast(msg: 'Tender Updated Successfully');
//           nameController.clear();
//           descriptionController.clear();
//           priceController.clear();
//           lastDateController.clear();
//           setState(() {
//             _selectedImage = null;
//           });
//           // Navigate to Home page and remove previous screens from stack
//           Navigator.pushAndRemoveUntil(
//             context,
//             MaterialPageRoute(builder: (context) => ManageTender()), // Navigate to Home
//                 (route) => false, // Remove all previous routes
//           );
//         } else {
//           Fluttertoast.showToast(msg: 'Error: tender not added.');
//         }
//       } else {
//         Fluttertoast.showToast(msg: 'Server Error: ${response.statusCode}');
//       }
//     } catch (e) {
//       Fluttertoast.showToast(msg: 'Network Error: ${e.toString()}');
//     }
//   }
//
//
//
//
// }



import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:tender_management/managetender.dart';
import 'dart:convert';

import 'Home.dart';

class EditTender extends StatefulWidget {
  const EditTender({Key? key}) : super(key: key);

  @override
  State<EditTender> createState() => _EditTenderState();
}

class _EditTenderState extends State<EditTender> {
  final _formKey = GlobalKey<FormState>();
  final  nameController = TextEditingController();
  final  descriptionController = TextEditingController();
  final  lastDateController = TextEditingController();
  final  priceController = TextEditingController();

  String? _oldImageUrl; // URL of the old image
  File? _selectedImage; // File object for the newly selected image

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _selectedImage = File(pickedFile.path);
      });
    }
  }

  @override
  void initState() {
    super.initState();
    _fetchTenderDetails();
  }

  // Fetch existing tender details from the server
  void _fetchTenderDetails() async {
    SharedPreferences sh = await SharedPreferences.getInstance();
    String url = sh.getString('url') ?? '';
    String tid = sh.getString('tid') ?? '';

    final Uri apiUrl = Uri.parse(url + 'contractortenderedit_view');
    print(apiUrl);
    try {
      final response = await http.post(apiUrl, body: {'tid': tid});
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        print(data);
        if (data['status'] == 'ok' && data['data'] != null && data['data'].isNotEmpty) {
          final tenderData = data['data'][0]; // Access the first item in the data array
          setState(() {
            nameController.text = tenderData['name'] ?? '';
            descriptionController.text = tenderData['description'] ?? '';
            lastDateController.text = tenderData['lastdate'] ?? '';
            priceController.text = tenderData['min_max'].toString() ?? '';
            _oldImageUrl = tenderData['document'] ?? '';
          });
        }
        else {
          Fluttertoast.showToast(msg: 'Failed to load data');
        }
      } else {
        Fluttertoast.showToast(msg: 'Network Error');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Tender'),
        backgroundColor: Colors.teal,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              _buildTextField("Name", nameController, "Please enter the name"),
              _buildTextField("Description", descriptionController, "Please enter a description"),
              _buildTextField("Last Date", lastDateController, "Please enter the last date"),
              _buildTextField("Price", priceController, "Please enter the price"),
              const SizedBox(height: 20),
              _buildImagePicker(),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _updateTender,
                child: const Text("Update Tender"),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Generic text field builder with added validation
  Padding _buildTextField(String label, TextEditingController controller, String validationMessage) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: TextFormField(
        controller: controller,
        decoration: InputDecoration(
          border: const OutlineInputBorder(),
          labelText: label,
        ),
        validator: (value) {
          if (value == null || value.isEmpty) {
            return validationMessage;
          }
          if (label == "Price") {
            // Validate that price is a number
            if (double.tryParse(value) == null) {
              return "Please enter a valid price";
            }
          }
          if (label == "Last Date") {
            // Validate last date format (simple check for now)
            RegExp dateRegex = RegExp(r'^\d{4}-\d{2}-\d{2}$');
            if (!dateRegex.hasMatch(value)) {
              return "Please enter a valid date (YYYY-MM-DD)";
            }
          }
          return null;
        },
      ),
    );
  }

  // Image picker widget
  Widget _buildImagePicker() {
    return Column(
      children: [
        GestureDetector(
          onTap: _checkPermissionAndChooseImage,
          child: Container(
            height: 200,
            width: 200,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.grey),
              borderRadius: BorderRadius.circular(8.0),
            ),
            child: _selectedImage != null
                ? Image.file(_selectedImage!, fit: BoxFit.cover)
                : _oldImageUrl != null && _oldImageUrl!.isNotEmpty
                ? Image.network(_oldImageUrl!, fit: BoxFit.cover)
                : const Center(
              child: Text("Select Image", style: TextStyle(color: Colors.grey)),
            ),
          ),
        ),
        const SizedBox(height: 8),
        const SizedBox(height: 20),
        // Image picker button
        ElevatedButton.icon(
          onPressed: _pickImage,
          icon: const Icon(Icons.camera_alt),
          label: Text(_selectedImage == null ? 'Pick an Image' : 'Image Selected'),
          style: ElevatedButton.styleFrom(
            backgroundColor: Colors.lightGreen,
          ),
        ),
        const Text("Tap to select an image"),
      ],
    );
  }

  // Method to choose and upload an image
  Future<void> _chooseAndUploadImage() async {
    final picker = ImagePicker();
    final pickedImage = await picker.pickImage(source: ImageSource.gallery);
    if (pickedImage != null) {
      setState(() {
        _selectedImage = File(pickedImage.path);
      });
    }
  }

  // Check permissions for image selection
  Future<void> _checkPermissionAndChooseImage() async {
    final PermissionStatus status = await Permission.photos.request();
    if (status.isGranted) {
      _chooseAndUploadImage();
    } else {
      _showPermissionDeniedDialog();
    }
  }

  // Show permission denied dialog
  void _showPermissionDeniedDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) => AlertDialog(
        title: const Text('Permission Denied'),
        content: const Text('Please enable photo permissions in your settings.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('OK'),
          ),
        ],
      ),
    );
  }

  // Method to update tender details
  void _updateTender() async {
    String details = descriptionController.text.trim();
    String name = nameController.text.trim();

    SharedPreferences sh = await SharedPreferences.getInstance();
    String? url = sh.getString('url');
    String? lid = sh.getString('tid');

    if (url == null || lid == null) {
      Fluttertoast.showToast(msg: 'Invalid configuration. Please try again.');
      return;
    }

    final Uri apiUrl = Uri.parse(url + "contractortende_edit");

    try {
      // Prepare the request to send the data and the file
      var request = http.MultipartRequest('POST', apiUrl)
        ..fields['name'] = name
        ..fields['desc'] = details
        ..fields['price'] = priceController.text // Using priceController text
        ..fields['last'] = lastDateController.text
        ..fields['tid'] = lid;

      // Attach the image file if it's selected
      if (_selectedImage != null) {
        var file = await http.MultipartFile.fromPath('document', _selectedImage!.path);
        request.files.add(file);
      }

      var response = await request.send();

      if (response.statusCode == 200) {
        final responseData = await response.stream.bytesToString();
        var data = jsonDecode(responseData);
        print(data);
        print('==================');

        if (data['status'] == 'ok') {
          Fluttertoast.showToast(msg: 'Tender Updated Successfully');
          nameController.clear();
          descriptionController.clear();
          priceController.clear();
          lastDateController.clear();
          setState(() {
            _selectedImage = null;
          });
          // Navigate to Home page and remove previous screens from stack
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(builder: (context) => ManageTender()), // Navigate to Home
                (route) => false, // Remove all previous routes
          );
        } else {
          Fluttertoast.showToast(msg: 'Error: tender not added.');
        }
      } else {
        Fluttertoast.showToast(msg: 'Server Error: ${response.statusCode}');
      }
    } catch (e) {
      Fluttertoast.showToast(msg: 'Network Error: ${e.toString()}');
    }
  }
}

