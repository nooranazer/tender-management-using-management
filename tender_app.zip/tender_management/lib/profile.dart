import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;

import 'edit_profile.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  String name = "";
  String email = "";
  String phone = "";
  String place = "";
  String pin = "";
  String post = "";
  String gender = "";
  String imageUrl = "";

  @override
  void initState() {
    super.initState();
    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    SharedPreferences sh = await SharedPreferences.getInstance();
    String url = sh.getString('url') ?? '';
    String lid = sh.getString('lid') ?? '';

    final urls = Uri.parse(url + 'and_view_profile');
    try {
      final response = await http.post(urls, body: {'lid': lid});
      if (response.statusCode == 200) {
        Fluttertoast.showToast(msg: "ooooooo");
        final data = jsonDecode(response.body);
        if (data['status'] == 'ok') {
          setState(() {
            name = data['name'] ?? "";
            email = data['email'] ?? "";
            phone = data['phone'].toString() ?? "";
            place = data['place'] ?? "";
            post = data['post'] ?? "";
            gender = data['gender'] ?? "";
            pin = data['pin'].toString() ?? "";
            imageUrl = sh.getString("imgurl").toString()+data['image'] ?? "";
            print("jhhhhhh$imageUrl");
          });
        } else {
          // Handle case where profile is not found
          Fluttertoast.showToast(msg: "pppp");
        }
      } else {
        // Handle network error
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "------"+e.toString());
      // Handle exception
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        backgroundColor: Colors.teal,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Profile Picture
              Container(
                margin: const EdgeInsets.only(bottom: 16.0),
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.grey.shade400),
                  borderRadius: BorderRadius.circular(12.0),
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12.0),
                  child: imageUrl.isNotEmpty
                      ? Image.network(
                    imageUrl,
                    fit: BoxFit.cover,
                    height: 320,
                    width: double.infinity,
                  )
                      : const Text('No Image Available'),
                ),
              ),
              // Profile Details
              Container(
                padding: const EdgeInsets.all(16.0),
                decoration: BoxDecoration(
                  color: Colors.grey.shade200,
                  borderRadius: BorderRadius.circular(12.0),
                  border: Border.all(color: Colors.grey.shade400),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildInfoRow(Icons.person, 'Name', name),
                    _buildInfoRow(Icons.person, 'Gender', gender),
                    _buildInfoRow(Icons.email, 'Email', email),
                    _buildInfoRow(Icons.phone, 'Phone', phone),
                    _buildInfoRow(Icons.location_on, 'Place', place),
                    _buildInfoRow(Icons.location_on, 'Post', post),
                    _buildInfoRow(Icons.pin, 'PIN', pin),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => EditProfile(),  // Navigate to the Edit Profile Page
                    ),
                  );
                },
                child: const Text('Edit Profile'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Icon(icon, size: 24),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
                Text(value.isNotEmpty ? value : 'N/A'), // Show 'N/A' if the value is empty
              ],
            ),
          ),
        ],
      ),
    );
  }
}
