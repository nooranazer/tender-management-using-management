from django.urls import path

from tenderapp import views

urlpatterns=[
path('',views.login),
    path('logincode',views.logincode),
    path('and_registrationcode',views.and_registrationcode),
    path('adminhome',views.adminhome),
    path('cp',views.cp),
    path('cp_post',views.cp_post),
    path('sendrply/<cid>',views.sendrply),
    path('replysend_post',views.replysend_post),
    path('contractoreply/<cid>',views.contractoreply),
    path('contractorsendreply_post',views.contractorsendreply_post),
    path('verfycmpny',views.verfycmpny),
    path('verfycompany_serach',views.verfycompany_serach),
    path('admin_accept_company/<lid>',views.admin_accept_company),
    path('admin_reject_company/<lid>',views.admin_reject_company),
    path('verfycmplaint',views.verfycmplaint),
    path('cmpnydate_serach',views.cmpnydate_serach),

    path('contractorcomplaint',views.contractorcomplaint),
    path('contractorcomplaint_post',views.contractorcomplaint_post),



    path('amount/<id>',views.amount),

    path('verfycontractors',views.verfycontractors),
    path('verfycontractors_serach',views.verfycontractors_serach),
    path('admin_accept_contractor/<lid>',views.admin_accept_contractor),
    path('admin_reject_contractors/<lid>',views.admin_reject_contractors),

    path('viewreview',views.viewreview),
    path('viewreview_post',views.viewreview_post),

    path('cmpnycp_post',views.cmpnycp_post),
    path('sendcmplnt_post',views.sendcmplnt_post),
    path('checkstatus',views.checkstatus),
    path('cmpnyhome',views.cmpnyhome),
    path('cmpnysignup',views.cmpnysignup),
    path('cmpnysignup_post',views.cmpnysignup_post),
    path('compnaycp',views.compnaycp),
    path('sendcmplaint',views.sendcmplaint),
    path('cmpnyreview',views.cmpnyreview),
    path('cmpnyreview_post',views.cmpnyreview_post),
    path('reqforbid',views.reqforbid),
    path('workersendreq',views.workersendreq),
    path('viewprofile',views.viewprofile),
    path('viewprofile_post',views.viewprofile_post),
    path('viewreply',views.viewreply),
    path('cpass',views.cpass),
    path('sendrply',views.sendrply),
    path('cmpanysgp',views.cmpanysgp),
    path('cmpnycp',views.cmpnycp),
    path('sendcomp',views.sendcomp),
    path('and_logincode',views.and_logincode),
    path('and_view_profile',views.and_view_profile),
    path('edit_prf',views.edit_prf),
    path('and_view_profile1',views.and_view_profile1),
    path('contractortender_view',views.contractortender_view),
    path('contractorpast_tender',views.contractorpast_tender),
    path('contractorongoing_tender',views.contractorongoing_tender),
    path('send_complaint',views.send_complaint, name='send_complaint'),
    path('DeleteMyComplaint',views.DeleteMyComplaint, name='DeleteMyComplaint'),
    path('view_complaintreply',views.view_complaintreply, name='view_complaintreply'),
    path('contractrotender_add', views.contractrotender_add, name='contractrotender_add'),
    path('contrctortender_delete', views.contrctortender_delete, name='contrctortender_delete'),
    path('contractortende_edit', views.contractortende_edit, name='contractortende_edit'),
    path('contractortenderedit_view', views.contractortenderedit_view, name='contractortenderedit_view'),
    path('viewtender_request', views.viewtender_request, name='viewtender_request'),
    path('update_tender_status', views.update_tender_status),
    path('viewtender_payment', views.viewtender_payment),
    path('updaterequeststatus', views.updaterequeststatus),
    path('and_user_view_profile', views.and_user_view_profile),










]