import datetime
import json

from django.contrib import auth
from django.core.files.storage import FileSystemStorage

from django.db.models import Q
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render

# Create your views here.
# from tenderapp.models import *
#
# from tender_management.tenderapp.models import contractor_complaints_table, tender_request_table, tender_table,\
#     login_table, contractor_table, review_table, company_complaints_table, company_table, payment_table
# from tender_management.tenderapp.models import company_table, login_table, contractor_complaints_table, \
#     contractor_table, tender_request_table, company_complaints_table, tender_table, payment_table, review_table
from tenderapp.models import *




from web3 import Web3, HTTPProvider
# truffle development blockchain address
blockchain_address = 'http://127.0.0.1:7545'
# Client instance to interact with the blockchain
web3 = Web3(HTTPProvider(blockchain_address,{"timeout": 80}))
# Set the default account (so we don't need to set the "from" for every transaction call)
web3.eth.defaultAccount = web3.eth.accounts[0]
compiled_contract_path = r"C:\Users\DELL\Documents\block_chain\node_modules\.bin\build\contracts\Structfund.json"
# Deployed contract address (see migrate command output: contract address)
deployed_contract_address = '0xb527706554455C4C901BCFFD9775FaaF5Cd738Ca'
# Create your views here.


def logout(request):
    auth.logout(request)
    return render(request,"loginindex.html")

def login(request):
    return render(request,'loginindex.html')
def logincode(request):
    username=request.POST['textfield']
    password=request.POST['textfield2']
    ob=login_table.objects.get(username=username,password=password)
    request.session["lid"]=ob.id

    if ob:
        # ob2 = login_table.objects.get(username=username, password=password)
        if ob.type=="admin":
            ob1=auth.authenticate(username='admin',password='admin')
            if ob1 is not None:
                auth.login(request,ob1)
                request.session['lid'] = ob.id


            return HttpResponse('''<script>alert("welcome");window.location='/adminhome'</script>''')
        elif ob.type=="company":
            return HttpResponse('''<script>alert("success");window,location='/cmpnyhome'</script>''')
        else:
            return HttpResponse('''<script>alert("Invalid");window,location='/'</script>''')

    else:
        return HttpResponse('''<script>alert("Invalid");window,location='/'</script>''')



def adminhome(request):
    return render(request,'admin/adminindex.html')
def cp(request):
    return render(request,'admin/change_pass.html')

def cp_post(request):
    currentpassword=request.POST['textfield']
    newpassword=request.POST['textfield2']
    confirmpassword=request.POST['textfield3']
    a = login_table.objects.filter(password=currentpassword)
    if a.exists():
        b = login_table.objects.get(password=currentpassword)
        if newpassword == confirmpassword:
            b.password = newpassword
            b.save()
            return HttpResponse('''<script>alert("success");window.location='/adminhome';</script>''')
        else:
            return HttpResponse('''<script>alert("Password Mismatches");window.location='/adminhome';</script>''')
    return HttpResponse('''<script>alert("Invalid credentials");window.location='/adminhome';</script>''')


def sendrply(request):
    return render(request,'admin/send_reply.html')


def verfycmpny(request):
    ob=company_table.objects.all()
    return render(request,'admin/verify_company.html',{'val':ob})

def verfycompany_serach(request):
    name=request.POST["textfield"]
    ob=company_table.objects.filter(name__contains=name)
    return render(request,'admin/verify_company.html',{'val':ob})

def admin_accept_company(request,lid):
    ob=login_table.objects.get(id=lid)
    ob.type = "company"
    ob.save()
    return HttpResponse('''<script>alert("Accepted..");window,location='/verfycmpny'</script>''')
def admin_reject_company(request,lid):
    ob=login_table.objects.get(id=lid)
    ob.type = "reject"
    ob.save()
    return HttpResponse('''<script>alert("rejected..");window,location='/verfycmpny'</script>''')

def verfycmplaint(request):
    ob=company_complaints_table.objects.all()
    return render(request,'admin/verify_complaint.html',{'val':ob})
def cmpnydate_serach(request):
    name=request.POST["textfield"]
    ob=company_complaints_table.objects.filter(date__contains=name)
    return render(request,'admin/verify_complaint.html',{'val':ob})

def sendrply(request,cid):
    request.session["cid"]=cid
    return render(request,'admin/send_reply.html')

def replysend_post(request):
    repy=request.POST['textfield']

    ob=company_complaints_table.objects.get(id=request.session["cid"])
    ob.reply=repy
    ob.save()
    return HttpResponse(
        '''<script>alert("replied..");window,location='/verfycmplaint';</script>''')


def contractorcomplaint(request):
    ob=contractor_complaints_table.objects.all()
    return render(request,'admin/contractor complaint.html',{'val':ob})


def contractorcomplaint_post(request):
    d=request.POST['d']
    ob=contractor_complaints_table.objects.filter(date__contains=d)
    return render(request,'admin/contractor complaint.html',{'val':ob})


def verfycontractors(request):
    ob=contractor_table.objects.all()
    return render(request,'admin/verify_contractors.html',{'val':ob})

def verfycontractors_serach(request):
    name=request.POST["textfield"]
    ob=contractor_table.objects.filter(name__contains=name)
    return render(request,'admin/verify_contractors.html',{'val':ob})

def admin_accept_contractor(request,lid):
    ob=login_table.objects.get(id=lid)
    ob.type="contractor"
    ob.save()
    return HttpResponse('''<script>alert("Accepted...");window,location='/verfycontractors'</script>''')
def admin_reject_contractors(request,lid):
    ob=login_table.objects.get(id=lid)
    ob.type = "reject"
    ob.save()
    return HttpResponse('''<script>alert("Rejected...");window,location='/verfycontractors';</script>''')


def viewreview(request):
    ob=review_table.objects.all()
    return render(request,'admin/view_review.html',{'val':ob})

def viewreview_post(request):
    d=request.POST['d']
    ob=review_table.objects.filter(date__contains=d)
    return render(request,'admin/view_review.html',{'val':ob})







# company




def checkstatus(request):
    a=tender_request_table.objects.filter(COMPANY__LOGIN_id=request.session['lid'])
    return render(request,'company/check status & make payment.html',{'data':a})

def cmpnyhome(request):
    return render(request,'company/companyindex.html')

def cmpnysignup(request):
    return render(request,'company/cmpny_signup.html')


def cmpnysignup_post(request):
    name=request.POST['textfield']
    img=request.FILES['file']
    idproof=request.FILES['idproof']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['textfield4']
    phone=request.POST['textfield5']
    email=request.POST['textfield6']
    username=request.POST['textfield7']
    password=request.POST['textfield8']

    fs=FileSystemStorage()
    date=datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S")+'.jpg'
    fs.save(date,img)
    path=fs.url(date)

    fn = FileSystemStorage()
    date = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
    fn.save(date, idproof)
    idprf = fn.url(date)





    ss=login_table.objects.filter(username=username)
    if ss.exists():
        return HttpResponse('''<script>alert("Already taken");window,location='/';</script>''')

    ob=login_table()
    ob.username=username
    ob.password=password
    ob.type='pending'
    ob.save()

    oc=company_table()
    oc.name=name
    oc.place=place
    oc.post=post
    oc.pin=pin
    oc.photo=path
    oc.idproof=idprf
    oc.phone=phone
    oc.email=email
    oc.LOGIN=ob
    oc.save()

    return HttpResponse('''<script>alert("Registered");window,location='/';</script>''')





def compnaycp(request):
    return render(request,'company/company change password.html')


def cmpnycp_post(request):
    currentpassword=request.POST['textfield']
    newpassword=request.POST['textfield2']
    confirmpassword=request.POST['textfield3']

    a = login_table.objects.filter(password=currentpassword)
    if a.exists():
        b = login_table.objects.get(password=currentpassword)
        if newpassword==confirmpassword:
            b.password=newpassword
            b.save()
            return HttpResponse('''<script>alert("success");window.location='/cmpnyhome';</script>''')
        else:
            return HttpResponse('''<script>alert("Password Mismatches");window.location='/cmpnyhome';</script>''')
    return HttpResponse('''<script>alert("Invalid credentials");window.location='/cmpnyhome';</script>''')


def reqforbid(request):
    a=tender_table.objects.all()
    print("jii")
    data = []
    for i in a:
        if tender_request_table.objects.filter(TENDER=i.id,status='accept').exists():
            pass
        else:
            data.append(i)
    print(data,"jkjk")
    return render(request,'company/send request for bid.html',{'data':data})

def amount(request,id):
    a = tender_table.objects.filter(id=id)
    request.session['cmpid']= id


    return render(request,'company/amount.html',{'data':a})


def workersendreq(request):
    amt = request.POST['amount']
    a=tender_table.objects.get(id=request.session['cmpid'])
    cc=tender_request_table()
    cc.COMPANY=company_table.objects.get(LOGIN_id=request.session['lid'])
    cc.TENDER=a
    cc.comp_amnt = amt
    cc.date=datetime.datetime.now().today().date()
    cc.status='requested'
    cc.save()
    pp = cc.id
    tid = a
    lid = request.session['lid']
    return HttpResponse('''<script>alert("request send");window.location='/reqforbid';</script>''')




def uploadfileblockchain(pp,lid,a,amt):
    print(pp,lid,a,amt,"kkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkk")
    # try:

    with open(compiled_contract_path) as file:
        contract_json = json.load(file)  # load contract info as JSON
        contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
    contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)

    blocknumber = web3.eth.get_block_number()
    message2 = contract.functions.addfund(blocknumber + 1, str(pp), str(lid),str(a),str(amt),

                                         str(datetime.datetime.now().date().strftime("%Y-%m-%d"))
                                         ).transact({'from': web3.eth.accounts[0]})

    print(message2)

    return "ok"
    # except Exception as e:
    #     print("==================")
    #     print("==================")
    #     print("==================")
    #     return str(e)



def sendcmplaint(request):
    return render(request,'company/send complaint.html')

def sendcmplnt_post(request):
    COMPLAINT=request.POST['textfield']

    a=company_complaints_table()
    a.COMPANY=company_table.objects.get(LOGIN_id=request.session['lid'])
    a.complaint=COMPLAINT
    a.date=datetime.datetime.now().date().today()
    a.reply='pending'
    a.save()
    return HttpResponse('''<script>alert("complaint send");window.location='/cmpnyhome';</script>''')


def reqforbid(request):
    a=tender_table.objects.all()
    print("jii")
    data = []
    for i in a:
        if tender_request_table.objects.filter(TENDER=i.id, status='accept').exists():
            pass
        else:
            data.append(i)
    print(data, "jkjk")
    return render(request,'company/send request for bid.html',{'data':data})




def viewprofile(request):
    a=company_table.objects.get(LOGIN_id=request.session['lid'])
    return render(request,'company/view profile and edit.html',{'data':a})

def viewprofile_post(request):
    NAME=request.POST['textfield']
    PLACE=request.POST['textfield2']
    POST=request.POST['textfield3']
    PIN=request.POST['textfield4']
    PHONE=request.POST['textfield5']
    EMAIL=request.POST['textfield6']
    a=company_table.objects.get(LOGIN_id=request.session['lid'])

    if 'file' in request.FILES:
        file = request.FILES['file']
        fs = FileSystemStorage()
        date = datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S") + '.jpg'
        fs.save(date, file)
        path = fs.url(date)
        a.photo=path


    a.name=NAME
    a.place=PLACE
    a.post=POST
    a.pin=PIN
    a.phone=PHONE
    a.email=EMAIL
    a.save()
    return HttpResponse('''<script>alert(" updated");window.location='/viewprofile#content';</script>''')






def viewreply(request):
    a=company_complaints_table.objects.filter(COMPANY__LOGIN_id=request.session['lid'])
    return render(request,'company/view reply.html',{'data':a})

def cpass(request):
    currentpass=request.POST['textfield']
    newpass=request.POST['textfield2']
    confirmpass=request.POST['textfield3']

    ob=login_table.objects.filter(id=request.session["lid"])
    if len(ob)>0:
        ob1 = login_table.objects.get(id=request.session["lid"])
        if ob1.password== currentpass:
            if newpass==confirmpass:
                ob1.password=confirmpass
                ob1.save()
                return HttpResponse(
                    '''<script>alert("passwords are matching..");window,location='/cp';</script>''')

            else:
                return HttpResponse('''<script>alert("password and new password not matching...");window,location='/cp';</script>''')
        else:
            return HttpResponse(
                '''<script>alert("password and current password correct...");window,location='/cp';</script>''')
    else:
        return HttpResponse(
        '''<script>alert("incorrect...");window,location='/cp';</script>''')


def contractoreply(request,cid):
    request.session["ccid"]=cid
    return render(request,'admin/contractor_reply.html')



def contractorsendreply_post(request):
    repl=request.POST['textfield']
    ob=contractor_complaints_table.objects.get(id=request.session["ccid"])
    ob.reply=repl
    ob.save()
    return HttpResponse(
        '''<script>alert("replied..");window,location='/contractorcomplaint';</script>''')

def cmpnyreview(request):
    return render(request,'company/send review.html')

# def cmpnyreview_post(request):
#     d=request.POST['d']
#     ob=review_table.objects.filter(date__contains=d)
#     return render(request,'company/send review.html',{'val':ob})



def cmpnyreview_post(request):
    review=request.POST['textfield']

    a=review_table()
    a.COMPANY=company_table.objects.get(LOGIN_id=request.session['lid'])
    a.review=review
    a.date=datetime.datetime.now().date().today()
    a.rating=request.POST.get('rating')
    a.login = login_table.objects.get(id=request.session['lid'])
    a.reply='pending'
    a.save()
    return HttpResponse('''<script>alert("review send");window.location='/cmpnyhome';</script>''')



def cmpanysgp (request):
    name=request.POST['textfield']
    place=request.POST['textfield2']
    post=request.POST['textfield3']
    pin=request.POST['texfield4']
    phone=request.POST['texfield5']
    email=request.POST['texfield6']
    username=request.POST['texfield7']
    password=request.POST['texfield8']
    lob=login_table()
    lob.username=username
    lob.password=password
    lob.type='company'
    lob.save()
    cob=company_table()
    cob.name=name
    cob.place=place
    cob.post=post
    cob.pin=pin
    cob.phone=phone
    cob.email=email
    cob.save()
    return
def cmpnycp (request):
    currentpass=request.POST['texfield']
    newpass=request.POST['texfield2']
    confopass=request.POST['texfield3']
    ccpob=company_table()
    ccpob.currentpass=currentpass
    ccpob.newpass=newpass
    ccpob.confopass=confopass
    ccpob.save()
    return
def sendcomp(request):
    complaint=request.POST['texfield']
    scob=company_table()
    scob.complaint=complaint
    scob.save()
    return
















def and_logincode(request):
    print(request.POST)
    un = request.POST['username']
    pwd = request.POST['password']
    print(un, pwd)
    try:
        ob = login_table.objects.get(username=un, password=pwd)

        if ob is None:
            data = {"task": "invalid"}
        else:
            print("in user function")
            # data = {"task": "valid", "lid": ob.id,"type":ob.type}
        return JsonResponse({"task": "valid", "lid": ob.id,"type":ob.type})
    except:
        data = {"task": "invalid"}
        # r = json.dumps(data)
        # r = json.dumps(data)
        # print(r)
        return JsonResponse({"task": "invalid"})
import base64
import uuid
from django.core.files.base import ContentFile
from django.http import JsonResponse
from django.contrib.auth.hashers import make_password
from .models import login_table, contractor_table
from django.conf import settings


def save_base64_image(base64_string):
    """Save a base64 image string as a file in the media folder."""
    try:
        # Ensure the base64 string is in the correct format
        if not base64_string.startswith('data:image/'):
            raise ValueError("Invalid base64 string format. Expected format: 'data:image/<format>;base64,'.")

        # Split the base64 string to extract format and image data
        format, imgstr = base64_string.split(';base64,')  # Extract format and image data
        ext = format.split('/')[-1]  # Get the file extension (e.g., jpg, png)

        # Generate a unique filename for the image
        image_name = f"{uuid.uuid4()}.{ext}"

        # Decode the Base64 string to binary data
        image_data = base64.b64decode(imgstr)

        # Define the file path to save the image
        file_path = f"{settings.MEDIA_ROOT}/{image_name}"

        # Write the image data to a file
        with open(file_path, 'wb') as f:
            f.write(image_data)

        # Return the image file path
        return file_path
    except Exception as e:
        raise ValueError(f"Error decoding base64 image: {str(e)}")


def and_registrationcode(request):
    try:
        # Fetch POST data
        name = request.POST.get('fname')
        pin = request.POST.get('pin')
        place = request.POST.get('place')
        post = request.POST.get('post')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        uname = request.POST.get('uname')
        gender = request.POST.get('gender')
        password = request.POST.get('password')
        base64_photo = request.POST.get('photo')  # Get Base64 string of the photo

        # Check if all required fields are present
        if not all([name, pin, place, post, email, phone, uname, gender, password]):
            return JsonResponse({"task": "invalid", "message": "Missing required fields."})

        # Create login entry with hashed password
        lob1 = login_table()
        lob1.username = uname
        lob1.password = password  # Secure password storage
        lob1.type = 'pending'
        lob1.save()

        # Save contractor data
        lob = contractor_table()
        lob.name = name
        lob.gender = gender
        lob.post = post
        lob.pin = pin
        lob.place = place
        lob.phone = phone
        lob.email = email
        lob.LOGIN = lob1

        # Save image if provided
        if base64_photo:
            photo_path = save_base64_image(base64_photo)
            print(photo_path,"ghghghgg")
            lob.photo = "/media/"+ str(photo_path.split('/')[-1])  # Save the file path to the photo field

        lob.save()
        print("Registration Successful:", lob)

        return JsonResponse({'task': 'valid', 'message': 'Registration successful'})

    except Exception as e:
        print("Error:", e)
        return JsonResponse({"task": "invalid", "message": str(e)})


def and_view_profile(request):
    print(request.POST)
    lid=request.POST['lid']
    user=contractor_table.objects.get(LOGIN__id=lid)
    print(user,"kkkkkkkk",user.photo.url)
    return JsonResponse({'status':'ok',
                         'id':user.id,
                         'name':user.name,
                         'gender':user.gender,
                         'place':user.place,
                         'post':user.post,
                         'pin':str(user.pin),
                         'image': '/media/' + str(user.photo.url).split('/')[-1],
                         'phone':str(user.phone),
                         'email': user.email,
                         })

def and_view_profile1(request):
    print(request.POST)
    lid=request.POST['lid']
    user=contractor_table.objects.get(LOGIN__id=lid)
    print(user,"kkkkkkkk",user.photo.url,'/media/' + str(user.photo.url).split('/')[-1])
    return JsonResponse({'status':'ok',
                         'id':user.id,
                         'name':user.name,
                         'gender':user.gender,
                         'place':user.place,
                         'post':user.post,
                         'pin':str(user.pin),
                         'image': '/media/' + str(user.photo.url).split('/')[-1],
                         'phone':str(user.phone),
                         'email': user.email,
                         })



def edit_prf(request):
    try:
        id = request.POST['lid']
        user = contractor_table.objects.get(LOGIN__id=id)
        user.name = request.POST['name']
        user.email = request.POST['email']
        ph= request.FILES['image']
        fs=FileSystemStorage()
        fn=fs.save(ph.name,ph)
        user.photo=fn
        user.phone = request.POST['phone']
        user.place = request.POST['place']
        user.pin = request.POST['pin']
        user.post = request.POST['post']
        user.save()
        return JsonResponse({'status':'ok'})
    except:
        id = request.POST['lid']
        user = contractor_table.objects.get(LOGIN__id=id)
        user.name = request.POST['name']
        user.email = request.POST['email']
        user.phone = request.POST['phone']
        user.place = request.POST['place']
        user.pin = request.POST['pin']
        user.post = request.POST['post']
        user.save()
        return JsonResponse({'status': 'ok'})




def contractrotender_add(request):

    name = request.POST['name']
    desc = request.POST['desc']
    lst = request.POST['lastdate']
    min_max = request.POST['minmax']
    document = request.FILES['files']
    lid= request.POST['lid']
    fs=FileSystemStorage()
    path=fs.save(document.name,document)


    lob1 = tender_table()
    lob1.name = name
    lob1.description = desc
    lob1.lastdate = lst
    lob1.min_max_prices = min_max
    lob1.document=document
    lob1.status='Added'
    lob1.CONTRACTOR=contractor_table.objects.get(LOGIN=lid)
    lob1.save()
    return JsonResponse({'status': 'ok'})


# def contractortender_view(request):
#     lid=request.POST["lid"]
#     ob=tender_table.objects.filter(CONTRACTOR__LOGIN=lid)
#     ls=[]
#     for i in ob:
#         r={"id":i.id,"name":i.name,"decription":i.description,"lastdate":i.lastdate,"min_max":i.min_max_prices,"document":i.document,"status":i.status}
#         ls.append(r)
#     print(ls)
#     return JsonResponse({"status":"ok","data":ls})


from django.http import JsonResponse


def contractortender_view(request):
    lid = request.POST["lid"]
    tenders = tender_table.objects.filter(CONTRACTOR__LOGIN__id=lid)

    tender_list = []
    for tender in tenders:
        tender_list.append({
            "id": tender.id,
            "name": tender.name,
            "description": tender.description,
            "lastdate": tender.lastdate.strftime("%Y-%m-%d") if tender.lastdate else "",
            "min_max": tender.min_max_prices,
            "document": request.build_absolute_uri(tender.document.url),
            "status": tender.status,
        })
    print(tender_list)

    return JsonResponse({"status": "ok", "data": tender_list})



def contractortenderedit_view(request):
    print (request.POST,"KJJJJJJJJJJJJJJJ")
    lid =  request.POST.get('tid')

    tenders = tender_table.objects.get(id=lid)

    data = {
            "id": tenders.id,
            "name": tenders.name,
            "description": tenders.description,
            "lastdate": tenders.lastdate.strftime("%Y-%m-%d") if tenders.lastdate else "",
            "min_max": tenders.min_max_prices,
            "document": request.build_absolute_uri(tenders.document.url),
        }
    print(tenders)

    return JsonResponse({'status':'ok','data':[data]})


def contractortende_edit(request):

    name = request.POST['name']
    desc = request.POST['desc']
    lst = request.POST['last']
    min_max = request.POST['price']
    tid= request.POST['tid']



    lob1 = tender_table.objects.get(id=tid)
    if 'document' in request.FILES:
        document = request.FILES['document']

        fs = FileSystemStorage()
        path = fs.save(document.name, document)
        lob1.document = path

        print(document)
    lob1.name = name
    lob1.description = desc
    lob1.lastdate = lst
    lob1.min_max_prices = min_max
    lob1.save()
    return JsonResponse({'status': 'ok'})

#
# def contrctortender_delete(request):
#     tid = request.POST['tid']
#     a=tender_table.objects.get(id=tid)
#     a.delete()
#     return JsonResponse({"status":'ok'})



from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import tender_table

def contrctortender_delete(request):
    tid = request.POST.get('tid')


    tender = tender_table.objects.get(id=int(tid))
    tender.delete()  # Delete the tender
    return JsonResponse({"status": "ok"})



from django.http import JsonResponse
import datetime
from .models import tender_table


def contractorpast_tender(request):
    lid = request.POST.get("lid")  # Use .get() to prevent KeyError if 'lid' is missing

    today_date = datetime.date.today()  # Simplified date fetching

    tenders = tender_table.objects.filter(
        CONTRACTOR__LOGIN__id=lid,
        lastdate__lt=datetime.datetime.today()

    )
    l = []
    print(tenders)
    for tender in tenders:
        l.append( {
                "name": tender.name,
                "description": tender.description,
                "lastdate": tender.lastdate.strftime("%Y-%m-%d") if tender.lastdate else "",
                "min_max": tender.min_max_prices,
                "document": tender.document.url if tender.document else "",
                "status": tender.status,
            })
    print(l)



    return JsonResponse({"status": "ok", "data": l})




def contractorongoing_tender(request):
    lid = request.POST["lid"]
    today_date = datetime.date.today()  # Simplified date fetching

    tenders = tender_table.objects.filter( CONTRACTOR__LOGIN__id=lid,
        lastdate__gt=datetime.datetime.today()

    )
    l = []
    print(tenders)
    for tender in tenders:
        l.append({
            "name": tender.name,
            "description": tender.description,
            "lastdate": tender.lastdate.strftime("%Y-%m-%d") if tender.lastdate else "",
            "min_max": tender.min_max_prices,
            "document": tender.document.url if tender.document else "",
            "status": tender.status,
        })
    print(l)

    return JsonResponse({"status": "ok", "data": l})


    # ob= tender_table.objects.filter(CONTRACTOR__LOGIN=lid,status="pending")
    # return JsonResponse({"status": 'ok'})


def viewtender_request(request):
    lid=request.POST["lid"]
    tid=request.POST["tid"]
    ob=tender_request_table.objects.filter(TENDER__CONTRACTOR__LOGIN=lid,TENDER=tid)
    l=[]
    for i in ob:

        if i.comp_amnt > 0:
            Amnt = i.comp_amnt
        else:
            Amnt ='no changes'
        l.append({'id':str(i.id),
                  "COMPANY": i.COMPANY.name,
                  "date": i.date,
                  "amount":Amnt,
                  "status": i.status,
                  })
    return JsonResponse({"status": 'ok','data':l})


def update_tender_status(request):
    try:
        print(request.POST)
        lid=request.POST["lid"]
        t_reqid=request.POST["tender_reqid"]
        tid=request.POST["tid"]
        status=request.POST["action"]
        print(lid,t_reqid,tid,status,"Tender request data")


        ob=tender_request_table.objects.get(id=t_reqid)
        ob.status=status
        ob.save()
        if status=="accept":

             data = tender_request_table.objects.get(id=t_reqid)

             company_id = data.COMPANY.id
             a = data.comp_amnt

             with open(compiled_contract_path) as file:
                 contract_json = json.load(file)  # load contract info as JSON
                 contract_abi = contract_json['abi']  # fetch contract's abi - necessary to call its functions
             contract = web3.eth.contract(address=deployed_contract_address, abi=contract_abi)

             blocknumber = web3.eth.get_block_number()
             message2 = contract.functions.addfund(blocknumber + 1,str(t_reqid),
                                                   str(company_id), str(lid), str(a),

                                                   str(datetime.datetime.now().date().strftime("%Y-%m-%d"))
                                                   ).transact({'from': web3.eth.accounts[0]})

    except Exception as e:
        print("iii--",e)
    return JsonResponse({"status": 'ok','data':1})



 # Ensure you import the correct model

# def update_tender_status(request):
#     try:
#         # Retrieve parameters from the request
#         lid = request.POST.get("lid")
#         tid = request.POST.get("tender_id")
#         action = request.POST.get("action")
#
#         # Ensure all required parameters are present
#         if not lid or not tid or not action:
#             return JsonResponse({"status": "error", "message": "Missing required parameters"}, status=400)
#
#         # Get the tender request object
#         tender_request = tender_request_table.objects.get(id=tid)
#
#         # Update the status based on the action ('accept' or 'reject')
#         if action == "accept":
#             tender_request.status = "Accepted"
#         elif action == "reject":
#             tender_request.status = "Rejected"
#         else:
#             return JsonResponse({"status": "error", "message": "Invalid action"}, status=400)
#
#         # Save the updated status
#         tender_request.save()
#
#         return JsonResponse({"status": "ok", "data": 1})
#
#     except tender_request_table.DoesNotExist:
#         return JsonResponse({"status": "error", "message": "Tender request not found"}, status=404)
#     except Exception as e:
#         return JsonResponse({"status": "error", "message": str(e)}, status=500)



def viewtender_payment(request):
    lid = request.POST["lid"]
    ob = payment_table.objects.filter(CONTRACTOR__LOGIN=lid)
    ls = []
    for i in ob:
        r = {"id": i.id, "amount": i.amount, "date": i.date, "status": i.status}
        ls.append(r)

    return JsonResponse({"status": "ok", "data": ls})
#
# def send_complaint(request):
#     try:
#
#         # date = request.POST['date']
#         # reply = request.POST['reply']
#         complaint= request.POST['complaint']
#
#
#
#         lob1 = contractor_complaints_table()
#         lob1.commplaint= complaint
#         lob1.date = datetime.now()
#         lob1.reply ='pending'
#         lob1.save()
#         return JsonResponse({'task': 'valid'})
#     except:
#
#         return JsonResponse({"task": "invalid"})


def send_complaint(request):
    from datetime import datetime
    id = request.POST['id']
    complaint = request.POST.get('complaint')
    contractor = contractor_table.objects.get(LOGIN=id)

    if not complaint:
        return JsonResponse({'task': 'invalid', 'error': 'Complaint is required'})

    contractor_complaints_table.objects.create(
        CONTRACTOR=contractor,
        complaint=complaint,
        date=datetime.now(),
        reply='pending'
    )
    return JsonResponse({'task': 'valid'})

def view_complaintreply(request):
    lid = request.POST["lid"]
    ob = contractor_complaints_table.objects.filter(CONTRACTOR__LOGIN=lid)
    ls = []
    for i in ob:
        ls.append({
            'id':i.id,
            'CONTRACTOR':i.CONTRACTOR.name,
            'date':i.date,
            'complaint':i.complaint,
            'reply':i.reply,
        })
    return JsonResponse({"status": "ok", "data": ls})

def DeleteMyComplaint(request):
    id=request.POST['complaint_id']
    com = contractor_complaints_table.objects.get(id=id)
    com.delete()
    return JsonResponse({"status": "ok"})

def updaterequeststatus(request):

    rid=request.POST['tenderreq_id']

    tob=tender_request_table.objects.get(id=rid)

    tob.status = "paid"
    tob.save()
    return JsonResponse({"status": "ok"})



def and_user_view_profile(request):
    lid=request.POST["lid"]
    ob=contractor_table.objects.get(LOGIN=lid)
    return JsonResponse({"status": "ok",
                         "name":ob.name,
                         "email":ob.email,
                         "img":ob.photo.url})




























