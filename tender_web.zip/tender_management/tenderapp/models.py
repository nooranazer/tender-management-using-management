from django.db import models

# Create your models here.

class login_table(models.Model):
    username=models.CharField(max_length=100)
    password=models.CharField(max_length=100)
    type=models.CharField(max_length=100)

class contractor_table(models.Model):
    LOGIN=models.ForeignKey(login_table,on_delete=models.CASCADE)
    name=models.CharField(max_length=100)
    gender=models.CharField(max_length=100)
    # idproof=models.FileField()
    place=models.CharField(max_length=100)
    post=models.CharField(max_length=100)
    pin=models.BigIntegerField()
    photo=models.FileField()
    phone=models.BigIntegerField()
    email=models.CharField(max_length=100)

class company_table(models.Model):
    LOGIN = models.ForeignKey(login_table, on_delete=models.CASCADE)
    name = models.CharField(max_length=100)
    idproof = models.FileField()
    place = models.CharField(max_length=100)
    post = models.CharField(max_length=100)
    pin = models.BigIntegerField()
    photo = models.FileField()
    phone = models.BigIntegerField()
    email = models.CharField(max_length=100)

class tender_table(models.Model):
    name = models.CharField(max_length=100)
    description= models.CharField(max_length=100)
    lastdate= models.DateField()
    min_max_prices= models.BigIntegerField()
    document= models.FileField()
    status= models.CharField(max_length=100)
    CONTRACTOR = models.ForeignKey(contractor_table, on_delete=models.CASCADE)


class tender_request_table(models.Model):
    COMPANY=models.ForeignKey(company_table,on_delete=models.CASCADE)
    TENDER= models.ForeignKey(tender_table, on_delete=models.CASCADE)
    comp_amnt = models.BigIntegerField(default='0')
    date= models.DateField()
    status = models.CharField(max_length=100)



class contractor_complaints_table(models.Model):
    CONTRACTOR = models.ForeignKey(contractor_table,on_delete=models.CASCADE)
    date = models.DateField()
    reply=models.CharField(max_length=100)
    complaint=models.CharField(max_length=100)



class company_complaints_table(models.Model):
    COMPANY = models.ForeignKey(company_table, on_delete=models.CASCADE)
    date = models.DateField()
    reply = models.CharField(max_length=100)
    complaint = models.CharField(max_length=100)



class payment_table(models.Model):
    REQUEST=models.ForeignKey(tender_request_table,on_delete=models.CASCADE)
    amount= models.BigIntegerField()
    date=models.DateField()
    status=models.CharField(max_length=100)

class review_table(models.Model):
    review=models.CharField(max_length=100)
    date=models.DateField()
    rating=models.FloatField()
    login=models.ForeignKey(login_table,on_delete=models.CASCADE)









