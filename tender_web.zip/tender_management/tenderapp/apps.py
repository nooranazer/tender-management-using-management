from django.apps import AppConfig


class TenderappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'tenderapp'
