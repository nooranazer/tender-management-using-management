/*
SQLyog Community v13.0.1 (64 bit)
MySQL - 10.4.32-MariaDB : Database - tender
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`tender` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `tender`;

/*Table structure for table `auth_group` */

DROP TABLE IF EXISTS `auth_group`;

CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_group` */

/*Table structure for table `auth_group_permissions` */

DROP TABLE IF EXISTS `auth_group_permissions`;

CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_group_permissions` */

/*Table structure for table `auth_permission` */

DROP TABLE IF EXISTS `auth_permission`;

CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_permission` */

insert  into `auth_permission`(`id`,`name`,`content_type_id`,`codename`) values 
(1,'Can add log entry',1,'add_logentry'),
(2,'Can change log entry',1,'change_logentry'),
(3,'Can delete log entry',1,'delete_logentry'),
(4,'Can view log entry',1,'view_logentry'),
(5,'Can add permission',2,'add_permission'),
(6,'Can change permission',2,'change_permission'),
(7,'Can delete permission',2,'delete_permission'),
(8,'Can view permission',2,'view_permission'),
(9,'Can add group',3,'add_group'),
(10,'Can change group',3,'change_group'),
(11,'Can delete group',3,'delete_group'),
(12,'Can view group',3,'view_group'),
(13,'Can add user',4,'add_user'),
(14,'Can change user',4,'change_user'),
(15,'Can delete user',4,'delete_user'),
(16,'Can view user',4,'view_user'),
(17,'Can add content type',5,'add_contenttype'),
(18,'Can change content type',5,'change_contenttype'),
(19,'Can delete content type',5,'delete_contenttype'),
(20,'Can view content type',5,'view_contenttype'),
(21,'Can add session',6,'add_session'),
(22,'Can change session',6,'change_session'),
(23,'Can delete session',6,'delete_session'),
(24,'Can view session',6,'view_session'),
(25,'Can add company_table',7,'add_company_table'),
(26,'Can change company_table',7,'change_company_table'),
(27,'Can delete company_table',7,'delete_company_table'),
(28,'Can view company_table',7,'view_company_table'),
(29,'Can add login_table',8,'add_login_table'),
(30,'Can change login_table',8,'change_login_table'),
(31,'Can delete login_table',8,'delete_login_table'),
(32,'Can view login_table',8,'view_login_table'),
(33,'Can add tender_table',9,'add_tender_table'),
(34,'Can change tender_table',9,'change_tender_table'),
(35,'Can delete tender_table',9,'delete_tender_table'),
(36,'Can view tender_table',9,'view_tender_table'),
(37,'Can add tender_request_table',10,'add_tender_request_table'),
(38,'Can change tender_request_table',10,'change_tender_request_table'),
(39,'Can delete tender_request_table',10,'delete_tender_request_table'),
(40,'Can view tender_request_table',10,'view_tender_request_table'),
(41,'Can add payment_table',11,'add_payment_table'),
(42,'Can change payment_table',11,'change_payment_table'),
(43,'Can delete payment_table',11,'delete_payment_table'),
(44,'Can view payment_table',11,'view_payment_table'),
(45,'Can add contractor_table',12,'add_contractor_table'),
(46,'Can change contractor_table',12,'change_contractor_table'),
(47,'Can delete contractor_table',12,'delete_contractor_table'),
(48,'Can view contractor_table',12,'view_contractor_table'),
(49,'Can add contractor_complaints_table',13,'add_contractor_complaints_table'),
(50,'Can change contractor_complaints_table',13,'change_contractor_complaints_table'),
(51,'Can delete contractor_complaints_table',13,'delete_contractor_complaints_table'),
(52,'Can view contractor_complaints_table',13,'view_contractor_complaints_table'),
(53,'Can add company_complaints_table',14,'add_company_complaints_table'),
(54,'Can change company_complaints_table',14,'change_company_complaints_table'),
(55,'Can delete company_complaints_table',14,'delete_company_complaints_table'),
(56,'Can view company_complaints_table',14,'view_company_complaints_table'),
(57,'Can add review_table',15,'add_review_table'),
(58,'Can change review_table',15,'change_review_table'),
(59,'Can delete review_table',15,'delete_review_table'),
(60,'Can view review_table',15,'view_review_table');

/*Table structure for table `auth_user` */

DROP TABLE IF EXISTS `auth_user`;

CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_user` */

/*Table structure for table `auth_user_groups` */

DROP TABLE IF EXISTS `auth_user_groups`;

CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_user_groups` */

/*Table structure for table `auth_user_user_permissions` */

DROP TABLE IF EXISTS `auth_user_user_permissions`;

CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `auth_user_user_permissions` */

/*Table structure for table `django_admin_log` */

DROP TABLE IF EXISTS `django_admin_log`;

CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `django_admin_log` */

/*Table structure for table `django_content_type` */

DROP TABLE IF EXISTS `django_content_type`;

CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `django_content_type` */

insert  into `django_content_type`(`id`,`app_label`,`model`) values 
(1,'admin','logentry'),
(3,'auth','group'),
(2,'auth','permission'),
(4,'auth','user'),
(5,'contenttypes','contenttype'),
(6,'sessions','session'),
(14,'tenderapp','company_complaints_table'),
(7,'tenderapp','company_table'),
(13,'tenderapp','contractor_complaints_table'),
(12,'tenderapp','contractor_table'),
(8,'tenderapp','login_table'),
(11,'tenderapp','payment_table'),
(15,'tenderapp','review_table'),
(10,'tenderapp','tender_request_table'),
(9,'tenderapp','tender_table');

/*Table structure for table `django_migrations` */

DROP TABLE IF EXISTS `django_migrations`;

CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `django_migrations` */

insert  into `django_migrations`(`id`,`app`,`name`,`applied`) values 
(1,'contenttypes','0001_initial','2024-09-30 10:27:32.980956'),
(2,'auth','0001_initial','2024-09-30 10:27:33.182902'),
(3,'admin','0001_initial','2024-09-30 10:27:33.230550'),
(4,'admin','0002_logentry_remove_auto_add','2024-09-30 10:27:33.237850'),
(5,'admin','0003_logentry_add_action_flag_choices','2024-09-30 10:27:33.243849'),
(6,'contenttypes','0002_remove_content_type_name','2024-09-30 10:27:33.274360'),
(7,'auth','0002_alter_permission_name_max_length','2024-09-30 10:27:33.300364'),
(8,'auth','0003_alter_user_email_max_length','2024-09-30 10:27:33.308840'),
(9,'auth','0004_alter_user_username_opts','2024-09-30 10:27:33.314967'),
(10,'auth','0005_alter_user_last_login_null','2024-09-30 10:27:33.337359'),
(11,'auth','0006_require_contenttypes_0002','2024-09-30 10:27:33.340710'),
(12,'auth','0007_alter_validators_add_error_messages','2024-09-30 10:27:33.347083'),
(13,'auth','0008_alter_user_username_max_length','2024-09-30 10:27:33.356083'),
(14,'auth','0009_alter_user_last_name_max_length','2024-09-30 10:27:33.365079'),
(15,'auth','0010_alter_group_name_max_length','2024-09-30 10:27:33.374296'),
(16,'auth','0011_update_proxy_permissions','2024-09-30 10:27:33.381298'),
(17,'auth','0012_alter_user_first_name_max_length','2024-09-30 10:27:33.388665'),
(18,'sessions','0001_initial','2024-09-30 10:27:33.406517'),
(19,'tenderapp','0001_initial','2024-09-30 10:27:33.605489'),
(20,'tenderapp','0002_review_table','2024-09-30 10:27:33.646986'),
(21,'tenderapp','0003_auto_20240929_1254','2024-09-30 10:27:33.718991');

/*Table structure for table `django_session` */

DROP TABLE IF EXISTS `django_session`;

CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `django_session` */

insert  into `django_session`(`session_key`,`session_data`,`expire_date`) values 
('fklx9db67vz3ke8pm8h5xmhcj65ihmtx','eyJsaWQiOjEsImNjaWQiOiIxIiwiY2lkIjoiMiJ9:1svI5X:jrl6lnRvEj-97ZHff4b1cYBstJ9hhWr9nEgyDa-KG9M','2024-10-14 15:13:27.468994'),
('imll5bkr42c616815usswjl1o0yg0joh','eyJsaWQiOjF9:1t4eUm:E75eWYyjN4U01JtzNlyd5BYnNMPPIZNAiNio80AWWUI','2024-11-09 10:58:12.740286');

/*Table structure for table `tenderapp_company_complaints_table` */

DROP TABLE IF EXISTS `tenderapp_company_complaints_table`;

CREATE TABLE `tenderapp_company_complaints_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `reply` varchar(100) NOT NULL,
  `complaint` varchar(100) NOT NULL,
  `COMPANY_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_company_co_COMPANY_id_d7870718_fk_tenderapp` (`COMPANY_id`),
  CONSTRAINT `tenderapp_company_co_COMPANY_id_d7870718_fk_tenderapp` FOREIGN KEY (`COMPANY_id`) REFERENCES `tenderapp_company_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_company_complaints_table` */

insert  into `tenderapp_company_complaints_table`(`id`,`date`,`reply`,`complaint`,`COMPANY_id`) values 
(2,'2024-09-30','ok','not good',1),
(3,'2024-09-30','pending','so bad',3);

/*Table structure for table `tenderapp_company_table` */

DROP TABLE IF EXISTS `tenderapp_company_table`;

CREATE TABLE `tenderapp_company_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_company_ta_LOGIN_id_33f8d31a_fk_tenderapp` (`LOGIN_id`),
  CONSTRAINT `tenderapp_company_ta_LOGIN_id_33f8d31a_fk_tenderapp` FOREIGN KEY (`LOGIN_id`) REFERENCES `tenderapp_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_company_table` */

insert  into `tenderapp_company_table`(`id`,`name`,`place`,`post`,`pin`,`photo`,`phone`,`email`,`LOGIN_id`) values 
(1,'sanil','clct','CLCT',678976,'2024-09-30-16-04-13.jpg',5678976,'vgghh',3),
(2,'nooraa','clct','clct',565689,'2024-09-30-14-24-38.jpg',456789,'ghj',2),
(3,'sheha','calicut','mangav',567897,'2024-09-30-16-38-12.jpg',2345678,'sheha@gmail.com',4),
(4,'john','kochi','kakkanad',673582,'2024-10-26-13-12-18.jpg',987654321,'john@gmail.com',5);

/*Table structure for table `tenderapp_contractor_complaints_table` */

DROP TABLE IF EXISTS `tenderapp_contractor_complaints_table`;

CREATE TABLE `tenderapp_contractor_complaints_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `reply` varchar(100) NOT NULL,
  `complaint` varchar(100) NOT NULL,
  `CONTRACTOR_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_contractor_CONTRACTOR_id_11b6c5ad_fk_tenderapp` (`CONTRACTOR_id`),
  CONSTRAINT `tenderapp_contractor_CONTRACTOR_id_11b6c5ad_fk_tenderapp` FOREIGN KEY (`CONTRACTOR_id`) REFERENCES `tenderapp_contractor_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_contractor_complaints_table` */

insert  into `tenderapp_contractor_complaints_table`(`id`,`date`,`reply`,`complaint`,`CONTRACTOR_id`) values 
(1,'2024-09-11','okkk','no',1);

/*Table structure for table `tenderapp_contractor_table` */

DROP TABLE IF EXISTS `tenderapp_contractor_table`;

CREATE TABLE `tenderapp_contractor_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `place` varchar(100) NOT NULL,
  `post` varchar(100) NOT NULL,
  `pin` bigint(20) NOT NULL,
  `photo` varchar(100) NOT NULL,
  `phone` bigint(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `LOGIN_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_contractor_LOGIN_id_7c30e0ac_fk_tenderapp` (`LOGIN_id`),
  CONSTRAINT `tenderapp_contractor_LOGIN_id_7c30e0ac_fk_tenderapp` FOREIGN KEY (`LOGIN_id`) REFERENCES `tenderapp_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_contractor_table` */

insert  into `tenderapp_contractor_table`(`id`,`name`,`gender`,`place`,`post`,`pin`,`photo`,`phone`,`email`,`LOGIN_id`) values 
(1,'GOV','M','CLCT','CLCT',675434,'FGHJ',76655,'GHJ',3);

/*Table structure for table `tenderapp_login_table` */

DROP TABLE IF EXISTS `tenderapp_login_table`;

CREATE TABLE `tenderapp_login_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_login_table` */

insert  into `tenderapp_login_table`(`id`,`username`,`password`,`type`) values 
(1,'admin','123','admin'),
(2,'company','123','company'),
(3,'saniil','noor','contractor'),
(4,'sheha','nas','company'),
(5,'john','456','company');

/*Table structure for table `tenderapp_payment_table` */

DROP TABLE IF EXISTS `tenderapp_payment_table`;

CREATE TABLE `tenderapp_payment_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `amount` bigint(20) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `REQUEST_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_payment_ta_REQUEST_id_e51f4953_fk_tenderapp` (`REQUEST_id`),
  CONSTRAINT `tenderapp_payment_ta_REQUEST_id_e51f4953_fk_tenderapp` FOREIGN KEY (`REQUEST_id`) REFERENCES `tenderapp_tender_request_table` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_payment_table` */

/*Table structure for table `tenderapp_review_table` */

DROP TABLE IF EXISTS `tenderapp_review_table`;

CREATE TABLE `tenderapp_review_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `review` varchar(100) NOT NULL,
  `date` date NOT NULL,
  `login_id` bigint(20) NOT NULL,
  `rating` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_review_tab_login_id_ec0e7962_fk_tenderapp` (`login_id`),
  CONSTRAINT `tenderapp_review_tab_login_id_ec0e7962_fk_tenderapp` FOREIGN KEY (`login_id`) REFERENCES `tenderapp_login_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_review_table` */

insert  into `tenderapp_review_table`(`id`,`review`,`date`,`login_id`,`rating`) values 
(1,'good','2024-09-10',2,5);

/*Table structure for table `tenderapp_tender_request_table` */

DROP TABLE IF EXISTS `tenderapp_tender_request_table`;

CREATE TABLE `tenderapp_tender_request_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  `COMPANY_id` bigint(20) NOT NULL,
  `TENDER_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `tenderapp_tender_req_COMPANY_id_f7570f5d_fk_tenderapp` (`COMPANY_id`),
  KEY `tenderapp_tender_req_TENDER_id_4b8ba0d2_fk_tenderapp` (`TENDER_id`),
  CONSTRAINT `tenderapp_tender_req_COMPANY_id_f7570f5d_fk_tenderapp` FOREIGN KEY (`COMPANY_id`) REFERENCES `tenderapp_company_table` (`id`),
  CONSTRAINT `tenderapp_tender_req_TENDER_id_4b8ba0d2_fk_tenderapp` FOREIGN KEY (`TENDER_id`) REFERENCES `tenderapp_tender_table` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_tender_request_table` */

insert  into `tenderapp_tender_request_table`(`id`,`date`,`status`,`COMPANY_id`,`TENDER_id`) values 
(1,'2024-09-30','requested',3,1);

/*Table structure for table `tenderapp_tender_table` */

DROP TABLE IF EXISTS `tenderapp_tender_table`;

CREATE TABLE `tenderapp_tender_table` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` varchar(100) NOT NULL,
  `lastdate` date NOT NULL,
  `min_max_prices` bigint(20) NOT NULL,
  `document` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

/*Data for the table `tenderapp_tender_table` */

insert  into `tenderapp_tender_table`(`id`,`name`,`description`,`lastdate`,`min_max_prices`,`document`,`status`) values 
(1,'noora','tender details','2024-10-01',1000,'.','');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
